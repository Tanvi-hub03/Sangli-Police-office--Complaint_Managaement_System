# क्विक स्टार्ट गाइड (Quick Start Guide)

## 🚀 5-मिनिट सेटअप (5-Minute Setup)

### Step 1: Install Python Dependencies
```bash
pip install flask flask-cors mysql-connector-python
```

### Step 2: Create MySQL Database
```sql
CREATE DATABASE spdata;
```

### Step 3: Update Database Configuration
Edit `app.py` lines 11-17:
```python
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': 'YOUR_MYSQL_PASSWORD',  # ← Change this
    'database': 'spdata',
    'port': 3306
}
```

### Step 4: Run Database Migration
```bash
python migrate_db.py
```

### Step 5: Start the Server
```bash
python app.py
```

### Step 6: Access the Application
Open browser: `http://localhost:5000`

---

## 📋 First Time Setup Checklist

- [ ] MySQL is running
- [ ] Database credentials updated in app.py
- [ ] Migration script executed successfully
- [ ] Flask server started without errors
- [ ] Browser can access http://localhost:5000

---

## 🧪 Quick Test

Run the automated test script:
```bash
pip install requests
python test_system.py
```

This will:
1. ✓ Register a test officer
2. ✓ Login with test officer
3. ✓ File a test complaint
4. ✓ View all complaints
5. ✓ Update complaint status

---

## 🔧 Troubleshooting

### "Connection refused"
- [ ] MySQL server not running
- [ ] Start MySQL: `mysql -u root -p`

### "Unknown database"
- [ ] Database not created
- [ ] Run: `CREATE DATABASE spdata;`

### "Access denied"
- [ ] Wrong MySQL password in app.py
- [ ] Check credentials and update DB_CONFIG

### "Table doesn't exist"
- [ ] Run migration: `python migrate_db.py`
- [ ] Or initialize: `python db.py`

---

## 📱 Default Admin Credentials

For admin login (if needed):
- Username: `admin`
- Password: `admin@1234`

---

## 🛠️ Important Files

| File | Purpose |
|------|---------|
| `app.py` | Flask backend server |
| `db.py` | Database schema |
| `migrate_db.py` | Add missing columns to existing DB |
| `CaseFile.html` | Main dashboard (for officers) |
| `Login.html` | Officer login page |
| `Registration.html` | Officer registration page |
| `test_system.py` | Automated testing script |

---

## 📞 System Architecture

```
┌─────────────────────────────────────────┐
│  Frontend (HTML/CSS/JavaScript)         │
│  ├─ Login.html                          │
│  ├─ Registration.html                   │
│  └─ CaseFile.html (Dashboard)           │
└──────────────┬──────────────────────────┘
               │ HTTP Requests
┌──────────────▼──────────────────────────┐
│  Backend (Flask Python)                 │
│  ├─ /api/register                       │
│  ├─ /api/login                          │
│  ├─ /api/save-complaint                 │
│  ├─ /api/get-all-complaints             │
│  ├─ /api/update-complaint-status        │
│  └─ /api/delete-complaint               │
└──────────────┬──────────────────────────┘
               │ SQL Queries
┌──────────────▼──────────────────────────┐
│  MySQL Database (spdata)                │
│  ├─ RegistrationInfo (Officers)         │
│  └─ Complaints (All complaints)         │
└─────────────────────────────────────────┘
```

---

## ✨ Key Features Implemented

### Officer Management
- ✅ Registration (Officer-only)
- ✅ Login with validation
- ✅ User authentication
- ✅ Session management

### Complaint Management
- ✅ File new complaints
- ✅ View all complaints (centralized)
- ✅ Update status (Pending ↔ Solved)
- ✅ Delete complaints
- ✅ Filter by name, mobile, status

### Dashboard
- ✅ Statistics (Total, Pending, Solved)
- ✅ Real-time complaint list
- ✅ Officer details displayed
- ✅ Status indicators with colors

### UI/UX
- ✅ Marathi language support
- ✅ Responsive design (mobile-friendly)
- ✅ Bootstrap 5 styling
- ✅ Date picker (Flatpickr)
- ✅ Form validation

---

## 🔐 Security Features

- ✓ User authentication
- ✓ Password storage (plain text - ⚠️ upgrade to bcrypt in production)
- ✓ SQL injection prevention (parameterized queries)
- ✓ CORS enabled for development
- ✓ Session management via sessionStorage

---

## 📊 Database Statistics

### RegistrationInfo Table
- Stores officer profile information
- Unique constraints on: user_name, Mobile_Number
- Auto-increment primary key (Sr_No)

### Complaints Table
- Stores all complaints from all officers
- Links to officer via userName
- Status tracking (Pending/Solved)
- Timestamps for tracking

---

## 🚀 Production Deployment

Before deploying to production:

1. **Security Upgrades**
   - [ ] Hash passwords with bcrypt
   - [ ] Implement SSL/TLS
   - [ ] Add CSRF protection
   - [ ] Implement rate limiting
   - [ ] Add audit logging

2. **Configuration**
   - [ ] Use environment variables for secrets
   - [ ] Change Flask debug to False
   - [ ] Configure CORS properly
   - [ ] Set up logging

3. **Database**
   - [ ] Regular backups
   - [ ] Database indexes optimized
   - [ ] Connection pooling enabled
   - [ ] User permissions restricted

4. **Testing**
   - [ ] Unit tests
   - [ ] Integration tests
   - [ ] Load testing
   - [ ] Security testing

---

## 📝 API Response Examples

### Register Officer
```json
{
  "success": true,
  "message": "Registration successful! Welcome, Officer Name!",
  "sr_no": 1
}
```

### Login Officer
```json
{
  "success": true,
  "message": "यशस्वीरित्या लॉगिन झाले!",
  "user": {
    "sr_no": 1,
    "name": "Officer Name",
    "username": "officer_username",
    "email": "officer@example.com",
    "mobile": "9876543210"
  },
  "redirect": "CaseFile.html"
}
```

### Get All Complaints
```json
{
  "success": true,
  "complaints": [
    {
      "complaint_id": 1,
      "inwardNo": "CMP-2025-001",
      "name": "Complainant Name",
      "mobile": "9999999999",
      "reason": "Complaint reason",
      "status": "Pending",
      "officer_name": "Officer Name",
      "officer_mobile": "9876543210",
      "submittedAt": "23-01-2026 14:30:00"
    }
  ],
  "count": 1
}
```

---

## 🎯 Common Tasks

### Add New Officer
1. Go to Registration page
2. Fill all details
3. Submit
4. Login with new credentials

### File Complaint
1. Login as officer
2. Click "नवीन तक्रार नोंदणी"
3. Fill complaint details
4. Submit
5. Complaint ID will be generated

### View All Complaints
1. Click "सर्व तक्रारा पहा"
2. Statistics dashboard loads
3. Table shows all complaints from all officers
4. Use filters to search

### Update Status
1. In complaint list
2. Click "अपडेट" button
3. Confirm status change
4. Database updates automatically

---

## 📞 Support

For issues:
1. Check migration was successful: `python migrate_db.py`
2. Verify database schema: `mysql -u root -p spdata < check_schema.sql`
3. Check server logs for errors
4. Verify all files are present in directory
5. Check browser console for JavaScript errors

---

**Last Updated:** January 23, 2026  
**System Version:** 1.0 - Officer-Only Release
