-- Create Complaints table for storing complaint data from CaseFile
CREATE TABLE IF NOT EXISTS Complaints (
    complaint_id INT PRIMARY KEY AUTO_INCREMENT,
    sr_no INT NOT NULL,
    inwardNo VARCHAR(50) NOT NULL,
    name VARCHAR(100) NOT NULL,
    mobile VARCHAR(10) NOT NULL,
    address TEXT,
    reason TEXT,
    date VARCHAR(50),
    district VARCHAR(100),
    deptSent VARCHAR(10),
    priority VARCHAR(50),
    submittedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    userName VARCHAR(50),
    INDEX idx_mobile (mobile),
    INDEX idx_sr_no (sr_no)
);
