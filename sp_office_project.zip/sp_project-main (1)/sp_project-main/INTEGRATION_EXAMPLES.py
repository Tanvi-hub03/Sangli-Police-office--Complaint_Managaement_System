"""
Integration Guide: How to use Notifications in your existing code

This file shows how to integrate the notification system with your 
existing complaint creation and update flows.
"""

# ============================================================================
# EXAMPLE 1: When complaint is created (in app.py)
# ============================================================================

def example_complaint_creation():
    """
    This is where you would add notification calls in your 
    complaint creation endpoint
    """
    from notifications import create_citizen_notification, generate_reminders_for_complaint
    
    # ... your existing complaint creation code ...
    
    # After successfully inserting complaint into database:
    complaint_id = 123  # The ID of newly created complaint
    mobile_number = "9876543210"
    citizen_name = "Raj Kumar"
    
    # 1. CREATE CITIZEN NOTIFICATION
    create_citizen_notification(
        complaint_id=complaint_id,
        mobile_number=mobile_number,
        citizen_name=citizen_name,
        notification_type='registered',
        message=f"Your complaint has been registered successfully (ID: #{complaint_id}). "
                f"Our officer will review and update you soon."
    )
    
    # 2. AUTO-GENERATE OFFICER REMINDERS
    generate_reminders_for_complaint(complaint_id)
    
    print("✓ Notification sent to citizen")
    print("✓ Reminders generated for officers")


# ============================================================================
# EXAMPLE 2: When complaint status is updated
# ============================================================================

def example_complaint_status_update():
    """
    Call this when you update a complaint status
    """
    from notifications import create_citizen_notification
    
    complaint_id = 123
    mobile_number = "9876543210"
    citizen_name = "Raj Kumar"
    new_status = "Updated"
    
    # SEND NOTIFICATION TO CITIZEN
    if new_status == "Updated":
        message = "Your complaint has been updated. Check dashboard for details."
    elif new_status == "Resolved":
        message = "Your complaint has been resolved. Thank you for your patience!"
    else:
        message = f"Your complaint status has changed to: {new_status}"
    
    create_citizen_notification(
        complaint_id=complaint_id,
        mobile_number=mobile_number,
        citizen_name=citizen_name,
        notification_type='updated',
        message=message
    )
    
    print("✓ Notification sent to citizen about status update")


# ============================================================================
# EXAMPLE 3: When complaint is resolved
# ============================================================================

def example_complaint_resolved():
    """
    Call this when a complaint is marked as resolved
    """
    from notifications import create_citizen_notification, resolve_reminder
    
    complaint_id = 123
    mobile_number = "9876543210"
    citizen_name = "Raj Kumar"
    
    # 1. SEND NOTIFICATION TO CITIZEN
    create_citizen_notification(
        complaint_id=complaint_id,
        mobile_number=mobile_number,
        citizen_name=citizen_name,
        notification_type='resolved',
        message="Your complaint has been successfully resolved. Thank you!"
    )
    
    # 2. MARK ALL RELATED REMINDERS AS RESOLVED
    # (You might need to query database first to get reminder IDs)
    # resolve_reminder(reminder_id)
    
    print("✓ Notification sent to citizen about resolution")
    print("✓ Reminders marked as resolved")


# ============================================================================
# EXAMPLE 4: Integration in Flask app.py
# ============================================================================

"""
Here's how to integrate into your existing Flask app.py file:

In your complaint creation endpoint, add these imports at the top:
"""

from flask import Flask, request, jsonify
from notifications import (
    create_citizen_notification,
    generate_reminders_for_complaint
)

# In your @app.route('/api/submit-complaint', methods=['POST']) function:

def integrated_complaint_endpoint():
    """
    This is where you would integrate notifications
    """
    connection = None
    cursor = None
    try:
        connection = get_db_connection()
        cursor = connection.cursor()
        
        # Extract form data
        data = request.get_json()
        mobile_number = data.get('mobile')
        citizen_name = data.get('name')
        reason = data.get('reason')
        priority = data.get('priority')
        # ... other fields ...
        
        # INSERT INTO COMPLAINTS TABLE
        cursor.execute("""
            INSERT INTO Complaints 
            (name, mobile, reason, priority, status, date, ...)
            VALUES (%s, %s, %s, %s, 'Pending', NOW(), ...)
        """, (citizen_name, mobile_number, reason, priority))
        
        connection.commit()
        complaint_id = cursor.lastrowid  # Get the created complaint ID
        
        # ✅ STEP 1: Create citizen notification
        create_citizen_notification(
            complaint_id=complaint_id,
            mobile_number=mobile_number,
            citizen_name=citizen_name,
            notification_type='registered',
            message=f"""
            आपली तक्रार यशस्वीरित्या नोंदवली गेली आहे।
            तक्रार क्रमांक: #{complaint_id}
            
            आपले तक्रार शीघ्रच पाहिले जाईल आणि आपणास अद्यतन दिले जाईल।
            """
        )
        
        # ✅ STEP 2: Auto-generate reminders for officers
        generate_reminders_for_complaint(complaint_id)
        
        return jsonify({
            'success': True,
            'complaint_id': complaint_id,
            'message': 'Complaint registered successfully'
        }), 201
        
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500
    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()


# ============================================================================
# EXAMPLE 5: Get reminders in Officer Login
# ============================================================================

def show_reminder_count_on_login():
    """
    After officer logs in, you can show reminder count
    """
    from notifications import get_reminder_statistics
    
    officer_id = 1
    
    stats = get_reminder_statistics(officer_id)
    
    # In your response, include:
    # {
    #   "login": "success",
    #   "officer_id": 1,
    #   "reminder_stats": {
    #       "total_active": 5,
    #       "overdue": 2,
    #       "high_priority": 3
    #   }
    # }
    
    return stats


# ============================================================================
# EXAMPLE 6: Database Query Examples
# ============================================================================

"""
Useful queries for checking notifications/reminders:

1. Check all unread notifications for a citizen:
   SELECT * FROM Notifications 
   WHERE mobile_number = '9876543210' AND is_read = FALSE;

2. Check overdue reminders for an officer:
   SELECT * FROM Reminders 
   WHERE officer_id = 1 AND is_resolved = FALSE AND due_date < NOW();

3. Check high priority pending reminders:
   SELECT * FROM Reminders 
   WHERE is_resolved = FALSE AND priority = 'High'
   ORDER BY due_date ASC;

4. Get total complaints by status:
   SELECT status, COUNT(*) 
   FROM Complaints 
   WHERE mobile = '9876543210' 
   GROUP BY status;

5. Check if citizen has acknowledged any complaints:
   SELECT c.complaint_id, r.is_acknowledged 
   FROM Complaints c 
   LEFT JOIN Reminders r ON c.complaint_id = r.complaint_id
   WHERE c.mobile = '9876543210';
"""


# ============================================================================
# EXAMPLE 7: Testing Notifications
# ============================================================================

def test_notification_system():
    """
    Quick test to verify everything is working
    """
    from notifications import (
        create_citizen_notification,
        get_citizen_notifications,
        get_officer_reminders,
        generate_reminders_for_complaint
    )
    
    # Test 1: Create a test notification
    print("Test 1: Creating notification...")
    result = create_citizen_notification(
        complaint_id=1,
        mobile_number='9876543210',
        citizen_name='Test User',
        notification_type='test',
        message='This is a test notification'
    )
    print(f"✓ Result: {result}")
    
    # Test 2: Retrieve notifications
    print("\nTest 2: Retrieving notifications...")
    notifications = get_citizen_notifications('9876543210')
    print(f"✓ Found {len(notifications)} notifications")
    for n in notifications:
        print(f"  - {n['message'][:50]}...")
    
    # Test 3: Get officer reminders
    print("\nTest 3: Retrieving officer reminders...")
    reminders = get_officer_reminders(1)
    print(f"✓ Found {len(reminders)} reminders for officer 1")
    for r in reminders:
        print(f"  - Complaint #{r['complaint_id']}: {r['reminder_message']}")
    
    print("\n✅ All tests passed!")


# ============================================================================
# SUMMARY: Integration Checklist
# ============================================================================

"""
✅ INTEGRATION CHECKLIST

To integrate notifications into your existing system:

1. □ Import functions at top of app.py:
   from notifications import (
       create_citizen_notification,
       generate_reminders_for_complaint,
       get_officer_reminders,
       acknowledge_reminder,
       resolve_reminder,
       get_reminder_statistics
   )

2. □ In complaint submission endpoint:
   - After INSERT complaint
   - Call: create_citizen_notification(...)
   - Call: generate_reminders_for_complaint(...)

3. □ In complaint update endpoint:
   - Call: create_citizen_notification(...) with 'updated' type
   - Update reminders if priority changes

4. □ In complaint resolution endpoint:
   - Call: create_citizen_notification(...) with 'resolved' type
   - Call: resolve_reminder(...) for all related reminders

5. □ In officer login:
   - Fetch: get_reminder_statistics(officer_id)
   - Display on dashboard

6. □ Test everything:
   - Create a complaint
   - Check notifications table
   - Check reminders table
   - Verify officer dashboard shows reminders
   - Verify citizen status page works

7. □ Deploy and monitor:
   - Watch for errors in logs
   - Verify timely creation of notifications
   - Check reminder accuracy
"""
