import mysql.connector
from mysql.connector import Error

try:
    connection = mysql.connector.connect(
        host='localhost',
        user='root',
        password='root',
        database='spdata',
        port=3407
    )

    if connection.is_connected():
        cursor = connection.cursor(dictionary=True)
        cursor.execute("SELECT COUNT(*) as total FROM Complaints WHERE priority LIKE '%अतितात्काळ%'")
        urgent_count = cursor.fetchone()['total']
        print(f'Urgent complaints (अतितात्काळ): {urgent_count}')

        if urgent_count > 0:
            cursor.execute("SELECT name, mobile, inwardNo FROM Complaints WHERE priority LIKE '%अतितात्काळ%' LIMIT 1")
            complaint = cursor.fetchone()
            print(f'Sample urgent complaint: {complaint}')

        # Also check total complaints
        cursor.execute("SELECT COUNT(*) as total FROM Complaints")
        total_count = cursor.fetchone()['total']
        print(f'Total complaints: {total_count}')

except Error as e:
    print(f'Error: {e}')
finally:
    if connection.is_connected():
        cursor.close()
        connection.close()