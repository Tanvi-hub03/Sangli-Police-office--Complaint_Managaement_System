#!/usr/bin/env python3
"""
System Testing Script
Tests all key functionalities of the complaint management system
"""

import requests
import json
from datetime import datetime

BASE_URL = "http://localhost:5000"

# Color codes for terminal output
GREEN = '\033[92m'
RED = '\033[91m'
YELLOW = '\033[93m'
RESET = '\033[0m'

def print_test(name, result, message=""):
    status = f"{GREEN}✓ PASS{RESET}" if result else f"{RED}✗ FAIL{RESET}"
    print(f"  {status} - {name}")
    if message:
        print(f"         {message}")

def test_health_check():
    """Test if server is running"""
    print(f"\n{YELLOW}Testing Server Health...{RESET}")
    try:
        response = requests.get(f"{BASE_URL}/api/health", timeout=5)
        result = response.status_code == 200
        print_test("Server is running", result, f"Status: {response.status_code}")
        return result
    except Exception as e:
        print_test("Server is running", False, f"Error: {str(e)}")
        return False

def test_officer_registration():
    """Test officer registration"""
    print(f"\n{YELLOW}Testing Officer Registration...{RESET}")
    
    # Generate unique username
    timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
    username = f"officer_{timestamp}"
    
    payload = {
        "fullName": f"Test Officer {timestamp}",
        "address": "Test Address",
        "dateOfBirth": "1990-01-15",
        "mobileNumber": "9876543210",
        "email": f"officer{timestamp}@test.com",
        "username": username,
        "password": "TestPass123"
    }
    
    try:
        response = requests.post(f"{BASE_URL}/api/register", json=payload, timeout=5)
        result = response.status_code == 200
        data = response.json()
        
        if result:
            sr_no = data.get('sr_no')
            print_test("Officer registration successful", True, f"SR No: {sr_no}, Username: {username}")
        else:
            print_test("Officer registration successful", False, f"Error: {data.get('message', 'Unknown error')}")
        
        return result, username, payload.get('password'), sr_no if result else None
    except Exception as e:
        print_test("Officer registration successful", False, f"Error: {str(e)}")
        return False, None, None, None

def test_officer_login(username, password):
    """Test officer login"""
    print(f"\n{YELLOW}Testing Officer Login...{RESET}")
    
    payload = {
        "username": username,
        "password": password
    }
    
    try:
        response = requests.post(f"{BASE_URL}/api/login", json=payload, timeout=5)
        result = response.status_code == 200
        data = response.json()
        
        if result:
            user_info = data.get('user', {})
            print_test("Officer login successful", True, f"Name: {user_info.get('name')}")
        else:
            print_test("Officer login successful", False, f"Error: {data.get('message', 'Unknown error')}")
        
        return result, data.get('user') if result else None
    except Exception as e:
        print_test("Officer login successful", False, f"Error: {str(e)}")
        return False, None

def test_save_complaint(sr_no, username):
    """Test filing a complaint"""
    print(f"\n{YELLOW}Testing Complaint Filing...{RESET}")
    
    timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
    
    payload = {
        "sr_no": sr_no,
        "inwardNo": f"CMP-{timestamp}",
        "name": "Test Complainant",
        "mobile": "9876543210",
        "address": "Test Address",
        "reason": "Test complaint reason",
        "date": f"{datetime.now().strftime('%d-%m-%Y')}",
        "district": "सांगली",
        "deptSent": "होय",
        "priority": "सामान्य - १ आठवडा",
        "userName": username
    }
    
    try:
        response = requests.post(f"{BASE_URL}/api/save-complaint", json=payload, timeout=5)
        result = response.status_code in [200, 201]
        data = response.json()
        
        if result:
            complaint_id = data.get('complaint_id')
            print_test("Complaint filed successfully", True, f"Complaint ID: {complaint_id}")
            return result, complaint_id
        else:
            print_test("Complaint filed successfully", False, f"Error: {data.get('message', 'Unknown error')}")
            return False, None
    except Exception as e:
        print_test("Complaint filed successfully", False, f"Error: {str(e)}")
        return False, None

def test_get_all_complaints():
    """Test retrieving all complaints"""
    print(f"\n{YELLOW}Testing Retrieve All Complaints...{RESET}")
    
    try:
        response = requests.get(f"{BASE_URL}/api/get-all-complaints", timeout=5)
        result = response.status_code == 200
        data = response.json()
        
        if result:
            count = data.get('count', 0)
            complaints = data.get('complaints', [])
            
            # Check if complaint includes officer details
            has_officer_info = False
            if complaints:
                complaint = complaints[0]
                has_officer_info = 'officer_name' in complaint and 'status' in complaint
            
            print_test("Retrieved all complaints", True, f"Total: {count}, Has officer info: {has_officer_info}")
            return result, complaints
        else:
            print_test("Retrieved all complaints", False, f"Error: {data.get('message', 'Unknown error')}")
            return False, None
    except Exception as e:
        print_test("Retrieved all complaints", False, f"Error: {str(e)}")
        return False, None

def test_update_complaint_status(complaint_id):
    """Test updating complaint status"""
    print(f"\n{YELLOW}Testing Update Complaint Status...{RESET}")
    
    if not complaint_id:
        print_test("Update complaint status", False, "No complaint ID provided")
        return False
    
    payload = {
        "status": "Solved"
    }
    
    try:
        response = requests.put(f"{BASE_URL}/api/update-complaint-status/{complaint_id}", json=payload, timeout=5)
        result = response.status_code == 200
        data = response.json()
        
        if result:
            print_test("Update complaint status", True, f"Status changed to: {payload['status']}")
            return result
        else:
            print_test("Update complaint status", False, f"Error: {data.get('message', 'Unknown error')}")
            return False
    except Exception as e:
        print_test("Update complaint status", False, f"Error: {str(e)}")
        return False

def run_all_tests():
    """Run all tests"""
    print(f"\n{'='*60}")
    print(f"तक्रार व्यवस्थापन प्रणाली - System Testing")
    print(f"{'='*60}")
    
    # Test 1: Health Check
    if not test_health_check():
        print(f"\n{RED}✗ Server is not running!{RESET}")
        print(f"{YELLOW}Start the server with: python app.py{RESET}")
        return False
    
    # Test 2: Officer Registration
    reg_result, username, password, sr_no = test_officer_registration()
    if not reg_result:
        print(f"\n{RED}✗ Officer registration failed!{RESET}")
        return False
    
    # Test 3: Officer Login
    login_result, user_info = test_officer_login(username, password)
    if not login_result:
        print(f"\n{RED}✗ Officer login failed!{RESET}")
        return False
    
    # Test 4: File Complaint
    complaint_result, complaint_id = test_save_complaint(sr_no, username)
    if not complaint_result:
        print(f"\n{RED}✗ Filing complaint failed!{RESET}")
        return False
    
    # Test 5: Get All Complaints
    get_result, complaints = test_get_all_complaints()
    if not get_result:
        print(f"\n{RED}✗ Retrieving complaints failed!{RESET}")
        return False
    
    # Test 6: Update Complaint Status
    update_result = test_update_complaint_status(complaint_id)
    if not update_result:
        print(f"\n{RED}✗ Updating complaint status failed!{RESET}")
        return False
    
    # Summary
    print(f"\n{'='*60}")
    print(f"{GREEN}✓ All tests passed!{RESET}")
    print(f"{'='*60}")
    
    print(f"\n{YELLOW}System is ready for use!{RESET}")
    print(f"- Access the application at: {BASE_URL}")
    print(f"- Login with username: {username}")
    
    return True

if __name__ == '__main__':
    try:
        run_all_tests()
    except KeyboardInterrupt:
        print(f"\n{RED}Testing interrupted by user{RESET}")
    except Exception as e:
        print(f"\n{RED}Unexpected error: {str(e)}{RESET}")
