#!/usr/bin/env python3
import mysql.connector
from mysql.connector import Error

def get_db_connection():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database="spdata",
        port=3407
    )

def fix_officer_names():
    """Update existing complaints with officer names"""
    connection = None
    cursor = None
    try:
        connection = get_db_connection()
        cursor = connection.cursor(dictionary=True)
        
        print("Fetching all officers...")
        cursor.execute("SELECT user_name, Name_of_Registerer, district FROM RegistrationInfo WHERE officer_role = 'officer'")
        officers = cursor.fetchall()
        
        if not officers:
            print("✗ No officers found!")
            return
        
        print(f"✓ Found {len(officers)} officers")
        
        for officer in officers:
            officer_name = officer['Name_of_Registerer']
            officer_district = officer['district']
            
            if officer_district:
                print(f"Updating complaints from {officer_district} district to officer: {officer_name}")
                
                cursor.execute("""
                    UPDATE Complaints
                    SET officerName = %s
                    WHERE district = %s AND (officerName IS NULL OR officerName = '')
                """, (officer_name, officer_district))
                
                connection.commit()
                print(f"  ✓ Updated {cursor.rowcount} complaints")
        
        # Show result
        cursor.execute("""
            SELECT complaint_id, inwardNo, name, district, officerName
            FROM Complaints
            ORDER BY complaint_id
        """)
        
        complaints = cursor.fetchall()
        print("\n" + "="*80)
        print("Updated Complaints:")
        print("="*80)
        for complaint in complaints:
            print(f"ID: {complaint['complaint_id']}, Inward: {complaint['inwardNo']}, Citizen: {complaint['name']}, District: {complaint['district']}, Officer: {complaint['officerName']}")
        
        print("="*80)
        print("✓ All complaints updated successfully!")
        
    except Error as e:
        print(f"✗ Database error: {e}")
    finally:
        if cursor:
            cursor.close()
        if connection and connection.is_connected():
            connection.close()

if __name__ == "__main__":
    fix_officer_names()
