#!/usr/bin/env python3
import mysql.connector
from mysql.connector import Error

def get_db_connection():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database="spdata",
        port=3407
    )

def add_district_column():
    """Add district column to RegistrationInfo if it doesn't exist"""
    connection = None
    cursor = None
    try:
        connection = get_db_connection()
        cursor = connection.cursor()
        
        print("Checking if district column exists...")
        
        # Check if district column exists
        cursor.execute("""
            SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS 
            WHERE TABLE_NAME='RegistrationInfo' AND COLUMN_NAME='district'
        """)
        
        if cursor.fetchone():
            print("✓ District column already exists")
        else:
            print("✗ District column not found. Adding it...")
            cursor.execute("""
                ALTER TABLE RegistrationInfo 
                ADD COLUMN district VARCHAR(100)
            """)
            connection.commit()
            print("✓ District column added successfully")
        
        # Update existing officers with their district based on their username/data
        # For testing, set all existing officers to 'सांगली' (Sangli)
        cursor.execute("""
            UPDATE RegistrationInfo 
            SET district = 'सांगली' 
            WHERE district IS NULL OR district = ''
        """)
        connection.commit()
        
        print("✓ Updated existing officers with default district (सांगली)")
        
        # Show officers and their districts
        cursor.execute("""
            SELECT Sr_No, Name_of_Registerer, user_name, district 
            FROM RegistrationInfo
        """)
        
        officers = cursor.fetchall()
        print("\n" + "="*80)
        print("Officers and their Districts:")
        print("="*80)
        for officer in officers:
            print(f"Sr.No: {officer[0]}, Name: {officer[1]}, Username: {officer[2]}, District: {officer[3]}")
        
        print("="*80)
        print("✓ All officers updated successfully!")
        
    except Error as e:
        print(f"✗ Database error: {e}")
    finally:
        if cursor:
            cursor.close()
        if connection and connection.is_connected():
            connection.close()

if __name__ == "__main__":
    add_district_column()
