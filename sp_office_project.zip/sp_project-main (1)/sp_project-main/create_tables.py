#!/usr/bin/env python3
"""
Create Initial Database Tables
"""

import mysql.connector
from mysql.connector import Error

def get_db_connection():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        port=3407
    )

def create_tables():
    """Create all required tables"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        # Use database
        cursor.execute("USE spdata;")
        print("✓ Using database: spdata")
        
        # Create RegistrationInfo table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS RegistrationInfo(
                Sr_No INT AUTO_INCREMENT PRIMARY KEY,
                Name_of_Registerer VARCHAR(50) NOT NULL,
                Address VARCHAR(100) NOT NULL,
                Date_of_birth DATE NOT NULL,
                Mobile_Number VARCHAR(10) NOT NULL UNIQUE,
                Email VARCHAR(100) NOT NULL,
                user_name VARCHAR(20) NOT NULL UNIQUE,
                Password VARCHAR(255) NOT NULL,
                officer_role VARCHAR(20) DEFAULT 'officer',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        print("✓ Created RegistrationInfo table")
        
        # Create Complaints table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS Complaints (
                complaint_id INT PRIMARY KEY AUTO_INCREMENT,
                sr_no INT NOT NULL,
                inwardNo VARCHAR(50) NOT NULL,
                name VARCHAR(100) NOT NULL,
                mobile VARCHAR(10) NOT NULL,
                address TEXT,
                reason TEXT,
                date VARCHAR(50),
                district VARCHAR(100),
                deptSent VARCHAR(10),
                priority VARCHAR(50),
                status VARCHAR(20) DEFAULT 'Pending',
                submittedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
                userName VARCHAR(50),
                INDEX idx_mobile (mobile),
                INDEX idx_sr_no (sr_no),
                INDEX idx_status (status)
            )
        """)
        print("✓ Created Complaints table")
        
        conn.commit()
        print("\n✓ ALL TABLES CREATED SUCCESSFULLY!")
        
    except Error as e:
        print(f"✗ Error: {e}")
    finally:
        cursor.close()
        conn.close()

if __name__ == '__main__':
    print("=" * 50)
    print("Creating Database Tables")
    print("=" * 50 + "\n")
    create_tables()
