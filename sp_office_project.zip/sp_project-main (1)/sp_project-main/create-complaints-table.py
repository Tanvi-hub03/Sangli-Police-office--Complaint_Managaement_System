import mysql.connector
from mysql.connector import Error

DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': 'root',
    'database': 'spdata',
    'port': 3407
}

try:
    connection = mysql.connector.connect(**DB_CONFIG)
    if connection.is_connected():
        cursor = connection.cursor()
        
        # Create Complaints table without foreign key constraint
        create_table_query = """
        CREATE TABLE IF NOT EXISTS Complaints (
            complaint_id INT PRIMARY KEY AUTO_INCREMENT,
            sr_no INT NOT NULL,
            inwardNo VARCHAR(50) NOT NULL,
            name VARCHAR(100) NOT NULL,
            mobile VARCHAR(10) NOT NULL,
            address TEXT,
            reason TEXT,
            date VARCHAR(50),
            district VARCHAR(100),
            deptSent VARCHAR(10),
            priority VARCHAR(50),
            submittedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
            userName VARCHAR(50),
            INDEX idx_mobile (mobile),
            INDEX idx_sr_no (sr_no)
        )
        """
        
        cursor.execute(create_table_query)
        connection.commit()
        print("✅ Complaints table created successfully!")
        
        # Verify table structure
        cursor.execute("DESC Complaints")
        columns = cursor.fetchall()
        print("\nTable Structure:")
        for col in columns:
            print(f"  - {col[0]}: {col[1]}")
        
        cursor.close()
        connection.close()
except Error as e:
    print(f"❌ Error: {e}")
