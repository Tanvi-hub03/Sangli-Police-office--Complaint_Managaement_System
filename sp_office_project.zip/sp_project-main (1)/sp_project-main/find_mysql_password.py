#!/usr/bin/env python3
"""
MySQL Credential Finder
Tries common MySQL passwords
"""

import mysql.connector
from mysql.connector import Error

def try_connection(password):
    """Try to connect with given password"""
    try:
        connection = mysql.connector.connect(
            host="localhost",
            user="root",
            password=password,
            port=3407
        )
        
        if connection.is_connected():
            print(f"✓ SUCCESS! Password is: '{password}'")
            connection.close()
            return True
        else:
            return False
            
    except Error as e:
        return False

# Common MySQL passwords to try
passwords = [
    "",                 # Empty password
    "root",            # Common default
    "admin",           # Common default
    "password",        # Common default
    "mysql",           # Common default
    "12345",           # Common default
    "123456",          # Common default
]

print("=" * 50)
print("MySQL Password Finder")
print("=" * 50)
print("\nTrying common passwords...\n")

found = False
for pwd in passwords:
    print(f"Trying password: '{pwd}'...", end=" ")
    if try_connection(pwd):
        found = True
        break
    else:
        print("✗ Failed")

if not found:
    print("\n❌ Could not find correct password")
    print("\nPlease enter the correct MySQL root password:")
    pwd = input("Password: ")
    if try_connection(pwd):
        print(f"\n✓ Found it! Password is: '{pwd}'")
    else:
        print("\n✗ That password didn't work either")
