#!/usr/bin/env python
import mysql.connector
from mysql.connector import Error

DB_CONFIG = {
    "host": "127.0.0.1",
    "user": "root",
    "password": "root",
    "database": "spdata",
    "port": 3407
}

def check_email_column():
    try:
        print("🔄 Connecting to MySQL...")
        connection = mysql.connector.connect(**DB_CONFIG)

        if connection.is_connected():
            print("✅ Connected to MySQL successfully!")
            cursor = connection.cursor()

            # Correct table & database name
            cursor.execute("""
                SELECT COLUMN_NAME
                FROM INFORMATION_SCHEMA.COLUMNS
                WHERE TABLE_NAME = 'RegistrationInfo'
                AND COLUMN_NAME = 'Email'
                AND TABLE_SCHEMA = 'spdata1'
            """)

            result = cursor.fetchone()

            if result:
                print("✅ Email column already exists in RegistrationInfo!")
            else:
                print("📝 Adding Email column...")
                cursor.execute("""
                    ALTER TABLE RegistrationInfo
                    ADD COLUMN Email VARCHAR(100) AFTER Mobile_Number
                """)
                connection.commit()
                print("✅ Email column added successfully!")

            print("\n📊 Table Structure:")
            cursor.execute("DESCRIBE RegistrationInfo")
            for col in cursor.fetchall():
                print(f"  - {col[0]} ({col[1]})")

            cursor.execute("SELECT COUNT(*) FROM RegistrationInfo")
            print(f"\n📈 Total Records: {cursor.fetchone()[0]}")

            cursor.close()
            connection.close()
            print("\n✅ Script executed successfully!")

    except Error as e:
        print(f"❌ MySQL Error: {e}")

if __name__ == "__main__":
    check_email_column()
