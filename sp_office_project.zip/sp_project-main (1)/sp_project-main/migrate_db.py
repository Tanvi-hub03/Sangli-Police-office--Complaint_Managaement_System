#!/usr/bin/env python3
"""
Database Migration Script
Adds new columns to existing tables to support officer-only system with status tracking
"""

import mysql.connector
from mysql.connector import Error

def get_db_connection():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database="spdata",
        port=3407
    )

def add_officer_role_column():
    """Add officer_role column to RegistrationInfo if it doesn't exist"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        # Check if column exists
        cursor.execute("""
            SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS 
            WHERE TABLE_NAME='RegistrationInfo' AND COLUMN_NAME='officer_role'
        """)
        
        if cursor.fetchone():
            print("✓ officer_role column already exists in RegistrationInfo table")
        else:
            # Add the column
            cursor.execute("""
                ALTER TABLE RegistrationInfo 
                ADD COLUMN officer_role VARCHAR(20) DEFAULT 'officer'
            """)
            conn.commit()
            print("✓ Added officer_role column to RegistrationInfo table")
            
            # Update existing records to have 'officer' role
            cursor.execute("""
                UPDATE RegistrationInfo SET officer_role = 'officer' WHERE officer_role IS NULL
            """)
            conn.commit()
            print("✓ Updated existing records with 'officer' role")
        
    except Error as e:
        print(f"✗ Error adding officer_role column: {e}")
    finally:
        cursor.close()
        conn.close()

def add_status_column():
    """Add status column to Complaints if it doesn't exist"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        # Check if column exists
        cursor.execute("""
            SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS 
            WHERE TABLE_NAME='Complaints' AND COLUMN_NAME='status'
        """)
        
        if cursor.fetchone():
            print("✓ status column already exists in Complaints table")
        else:
            # Add the column
            cursor.execute("""
                ALTER TABLE Complaints 
                ADD COLUMN status VARCHAR(20) DEFAULT 'Pending'
            """)
            conn.commit()
            print("✓ Added status column to Complaints table")
            
            # Update existing records to have 'Pending' status
            cursor.execute("""
                UPDATE Complaints SET status = 'Pending' WHERE status IS NULL
            """)
            conn.commit()
            print("✓ Updated existing records with 'Pending' status")
        
        # Add index on status column for better performance
        cursor.execute("""
            SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.STATISTICS
            WHERE TABLE_NAME='Complaints' AND COLUMN_NAME='status'
        """)
        
        if not cursor.fetchone():
            cursor.execute("""
                ALTER TABLE Complaints ADD INDEX idx_status (status)
            """)
            conn.commit()
            print("✓ Added index on status column")
        
    except Error as e:
        print(f"✗ Error adding status column: {e}")
    finally:
        cursor.close()
        conn.close()

def verify_database_schema():
    """Verify the database schema is correct"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        print("\n--- Verifying Database Schema ---")
        
        # Check RegistrationInfo table
        cursor.execute("""
            DESCRIBE RegistrationInfo
        """)
        print("\nRegistrationInfo table columns:")
        for row in cursor.fetchall():
            print(f"  - {row[0]} ({row[1]})")
        
        # Check Complaints table
        cursor.execute("""
            DESCRIBE Complaints
        """)
        print("\nComplaints table columns:")
        for row in cursor.fetchall():
            print(f"  - {row[0]} ({row[1]})")
        
        print("\n✓ Database schema verification complete")
        
    except Error as e:
        print(f"✗ Error verifying schema: {e}")
    finally:
        cursor.close()
        conn.close()

if __name__ == '__main__':
    print("=" * 50)
    print("Database Migration Script")
    print("=" * 50)
    print("\nStarting database migration...\n")
    
    try:
        add_officer_role_column()
        add_status_column()
        verify_database_schema()
        
        print("\n" + "=" * 50)
        print("✓ Migration completed successfully!")
        print("=" * 50)
    except Exception as e:
        print(f"\n✗ Migration failed: {e}")
        print("=" * 50)
