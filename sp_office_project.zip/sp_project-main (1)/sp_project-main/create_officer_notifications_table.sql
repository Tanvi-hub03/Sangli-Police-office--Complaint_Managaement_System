-- Create OfficerNotifications table
CREATE TABLE IF NOT EXISTS OfficerNotifications (
    notification_id INT AUTO_INCREMENT PRIMARY KEY,
    officer_id INT NOT NULL,
    complaint_id INT,
    title VARCHAR(100) NOT NULL,
    message TEXT NOT NULL,
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (officer_id) REFERENCES RegistrationInfo(Sr_No),
    FOREIGN KEY (complaint_id) REFERENCES Complaints(complaint_id)
);
