"""
Notification and Reminder Management System
"""

import mysql.connector
from mysql.connector import Error
from datetime import datetime, timedelta

DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': 'root',
    'database': 'spdata',
    'port': 3407
}

# Quick test mode: when True, reminders use short intervals (minutes) for fast testing.
# Set to False in production.
QUICK_REMINDERS = True

# Reminder intervals in minutes (default production values)
REMINDER_INTERVAL_MINUTES = {
    'High': 1,      # 1 minute for testing
    'Medium': 1,    # 1 minute for testing
    'Normal': 1     # 1 minute for testing
}

def get_db_connection():
    """Create and return database connection"""
    try:
        connection = mysql.connector.connect(**DB_CONFIG)
        if connection.is_connected():
            return connection
    except Error as e:
        print(f"Error connecting to MySQL: {e}")
        return None

# ============================================================================
# OFFICER NOTIFICATIONS (IN-APP POPUP)
# ============================================================================

def create_officer_notification(officer_id, complaint_id, title, message):
    """
    Create an in-app notification for an officer
    """
    connection = None
    cursor = None
    try:
        connection = get_db_connection()
        if not connection:
            return False
        
        cursor = connection.cursor()
        
        cursor.execute("""
            INSERT INTO OfficerNotifications (
                officer_id, complaint_id, title, message, is_read
            ) VALUES (%s, %s, %s, %s, FALSE)
        """, (officer_id, complaint_id, title, message))
        
        connection.commit()
        print(f"✓ Notification created for Officer {officer_id}: {title}")
        return True
        
    except Error as e:
        print(f"Error creating officer notification: {e}")
        return False
    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()

def get_officer_notifications(officer_id, unread_only=True):
    """Get notifications for an officer"""
    connection = None
    cursor = None
    try:
        connection = get_db_connection()
        if not connection:
            return []
        
        cursor = connection.cursor(dictionary=True)
        
        query = "SELECT * FROM OfficerNotifications WHERE officer_id = %s"
        params = [officer_id]
        
        if unread_only:
            query += " AND is_read = FALSE"
            
        query += " ORDER BY created_at DESC"
        
        cursor.execute(query, tuple(params))
        
        notifications = cursor.fetchall()
        
        # Format timestamps as DD/MM/YYYY, HH:MM:SS (server is already in IST)
        for notif in notifications:
            if notif.get('created_at'):
                try:
                    ts = notif['created_at']
                    # Format without timezone conversion (server stores in IST already)
                    notif['created_at'] = ts.strftime('%d/%m/%Y, %H:%M:%S')
                except Exception as e:
                    print(f"Error formatting timestamp: {e}")
        
        return notifications
        
    except Error as e:
        print(f"Error fetching officer notifications: {e}")
        return []
    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()

def mark_officer_notification_read(notification_id):
    """Mark officer notification as read"""
    connection = None
    cursor = None
    try:
        connection = get_db_connection()
        if not connection:
            return False
        
        cursor = connection.cursor()
        
        cursor.execute("""
            UPDATE OfficerNotifications 
            SET is_read = TRUE 
            WHERE notification_id = %s
        """, (notification_id,))
        
        connection.commit()
        return cursor.rowcount > 0
        
    except Error as e:
        print(f"Error marking notification as read: {e}")
        return False
    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()

# ============================================================================
# CITIZEN NOTIFICATIONS
# ============================================================================

def create_citizen_notification(complaint_id, mobile_number, citizen_name, notification_type, message):
    """
    Create a notification for citizen
    notification_type: 'registered', 'updated', 'resolved'
    """
    connection = None
    cursor = None
    try:
        connection = get_db_connection()
        if not connection:
            return False
        
        cursor = connection.cursor()
        
        cursor.execute("""
            INSERT INTO Notifications (
                complaint_id, mobile_number, citizen_name, 
                notification_type, message, is_read
            ) VALUES (%s, %s, %s, %s, %s, FALSE)
        """, (complaint_id, mobile_number, citizen_name, notification_type, message))
        
        connection.commit()
        return True
        
    except Error as e:
        print(f"Error creating notification: {e}")
        return False
    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()

def get_citizen_notifications(mobile_number):
    """Get all notifications for a citizen"""
    connection = None
    cursor = None
    try:
        connection = get_db_connection()
        if not connection:
            return []
        
        cursor = connection.cursor(dictionary=True)
        
        cursor.execute("""
            SELECT * FROM Notifications 
            WHERE mobile_number = %s 
            ORDER BY created_at DESC
        """, (mobile_number,))
        
        notifications = cursor.fetchall()
        return notifications
        
    except Error as e:
        print(f"Error fetching notifications: {e}")
        return []
    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()

def mark_notification_as_read(notification_id):
    """Mark notification as read"""
    connection = None
    cursor = None
    try:
        connection = get_db_connection()
        if not connection:
            return False
        
        cursor = connection.cursor()
        
        cursor.execute("""
            UPDATE Notifications 
            SET is_read = TRUE 
            WHERE notification_id = %s
        """, (notification_id,))
        
        connection.commit()
        return cursor.rowcount > 0
        
    except Error as e:
        print(f"Error marking notification as read: {e}")
        return False
    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()

# ============================================================================
# OFFICER REMINDERS
# ============================================================================

def create_officer_reminder(complaint_id, officer_id, priority, due_date, reminder_message):
    """
    Create a reminder for officer
    priority: 'High', 'Medium', 'Normal'
    """
    connection = None
    cursor = None
    try:
        connection = get_db_connection()
        if not connection:
            return False
        
        cursor = connection.cursor()
        
        # Calculate pending days
        if due_date:
            due_datetime = datetime.fromisoformat(due_date) if isinstance(due_date, str) else due_date
            pending_days = (due_datetime - datetime.now()).days
        else:
            pending_days = 0
        
        cursor.execute("""
            INSERT INTO Reminders (
                complaint_id, officer_id, priority, 
                due_date, pending_days, reminder_message
            ) VALUES (%s, %s, %s, %s, %s, %s)
        """, (complaint_id, officer_id, priority, due_date, pending_days, reminder_message))
        
        connection.commit()
        return True
        
    except Error as e:
        print(f"Error creating reminder: {e}")
        return False
    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()

def get_officer_reminders(officer_id):
    """Get all active reminders for an officer"""
    connection = None
    cursor = None
    try:
        connection = get_db_connection()
        if not connection:
            return []
        
        cursor = connection.cursor(dictionary=True)
        
        cursor.execute("""
            SELECT r.*, c.name, c.reason, c.priority 
            FROM Reminders r
            JOIN Complaints c ON r.complaint_id = c.complaint_id
            WHERE r.officer_id = %s 
            AND r.is_resolved = FALSE
            ORDER BY 
                CASE 
                    WHEN r.priority = 'High' THEN 1
                    WHEN r.priority = 'Medium' THEN 2
                    ELSE 3
                    END,
                r.due_date ASC
        """, (officer_id,))
        
        reminders = cursor.fetchall()
        return reminders
        
    except Error as e:
        print(f"Error fetching reminders: {e}")
        return []
    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()

def get_overdue_reminders(officer_id):
    """Get overdue reminders for an officer"""
    connection = None
    cursor = None
    try:
        connection = get_db_connection()
        if not connection:
            return []
        
        cursor = connection.cursor(dictionary=True)
        
        cursor.execute("""
            SELECT r.*, c.name, c.reason, c.priority 
            FROM Reminders r
            JOIN Complaints c ON r.complaint_id = c.complaint_id
            WHERE r.officer_id = %s 
            AND r.is_resolved = FALSE
            AND r.due_date < NOW()
            ORDER BY r.due_date ASC
        """, (officer_id,))
        
        reminders = cursor.fetchall()
        return reminders
        
    except Error as e:
        print(f"Error fetching overdue reminders: {e}")
        return []
    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()

def acknowledge_reminder(reminder_id):
    """Mark reminder as acknowledged"""
    connection = None
    cursor = None
    try:
        connection = get_db_connection()
        if not connection:
            return False
        
        cursor = connection.cursor()
        
        cursor.execute("""
            UPDATE Reminders 
            SET is_acknowledged = TRUE 
            WHERE reminder_id = %s
        """, (reminder_id,))
        
        connection.commit()
        return cursor.rowcount > 0
        
    except Error as e:
        print(f"Error acknowledging reminder: {e}")
        return False
    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()

def resolve_reminder(reminder_id):
    """Mark reminder as resolved"""
    connection = None
    cursor = None
    try:
        connection = get_db_connection()
        if not connection:
            return False
        
        cursor = connection.cursor()
        
        cursor.execute("""
            UPDATE Reminders 
            SET is_resolved = TRUE, is_acknowledged = TRUE
            WHERE reminder_id = %s
        """, (reminder_id,))
        
        connection.commit()
        return cursor.rowcount > 0
        
    except Error as e:
        print(f"Error resolving reminder: {e}")
        return False
    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()

# ============================================================================
# AUTO-GENERATE REMINDERS (to be called when complaint is created/updated)
# ============================================================================

def generate_reminders_for_complaint(complaint_id):
    """
    Auto-generate reminders for *the assigned* officer based on complaint priority.
    """
    connection = None
    cursor = None
    try:
        connection = get_db_connection()
        if not connection:
            return False
        
        cursor = connection.cursor(dictionary=True)
        
        # Get complaint details
        cursor.execute("""
            SELECT complaint_id, priority, submittedAt, name, officerName, userName 
            FROM Complaints 
            WHERE complaint_id = %s
        """, (complaint_id,))
        
        complaint = cursor.fetchone()
        if not complaint:
            return False
        
        priority = complaint['priority']
        
        # Determine time limit and due date (use minutes mapping)
        if QUICK_REMINDERS:
            minutes = 1
        else:
            # Map priority keywords to minutes
            if priority and ('High' in priority or 'अतितात्काळ' in priority):
                minutes = REMINDER_INTERVAL_MINUTES.get('High', 60)
            elif priority and ('Medium' in priority or 'तात्काळ' in priority):
                minutes = REMINDER_INTERVAL_MINUTES.get('Medium', 120)
            else:
                minutes = REMINDER_INTERVAL_MINUTES.get('Normal', 1440)

        due_date = datetime.now() + timedelta(minutes=minutes)
        
        # Find the specific officer assigned
        # Assuming 'officerName' or 'userName' holds the identifier used in RegistrationInfo
        # We need to map officerName/userName to RegistrationInfo.Sr_No
        
        # Strategy: Try to find officer by user_name first (as it's unique), then by Name_of_Registerer
        officer_user_name = complaint['userName'] # Assuming this is who filed it/was assigned?
        # Actually user requirement says "Officers can file new complaints". So userName is the officer.
        # But wait, there is also 'officerName'. Let's check db schema again in my mind.
        # Complaints table has: userName, officerName.
        # RegistrationInfo has: user_name, Name_of_Registerer.
        
       
        target_officer = None
        
        # Try finding by user_name
        cursor.execute("SELECT Sr_No FROM RegistrationInfo WHERE user_name = %s", (officer_user_name,))
        result = cursor.fetchone()
        
        if result:
            target_officer = result
        else:
            # Try finding by name (officerName in complaint)
             cursor.execute("SELECT Sr_No FROM RegistrationInfo WHERE Name_of_Registerer = %s", (complaint['officerName'],))
             target_officer = cursor.fetchone()
        
        if target_officer:
            officer_id = target_officer['Sr_No']
            reminder_message = f"Complaint ID #{complaint_id} ({complaint['name']}) - Priority: {priority}"
            
            create_officer_reminder(
                complaint_id=complaint_id,
                officer_id=officer_id,
                priority=priority,
                due_date=due_date.isoformat(),
                reminder_message=reminder_message
            )
            print(f"✓ Reminder generated for Officer ID {officer_id}")
            return True
        else:
            print(f"⚠️ Could not find officer record for complaint {complaint_id}")
            return False
        
    except Error as e:
        print(f"Error generating reminders: {e}")
        return False
    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()

def get_reminder_statistics(officer_id):
    """Get reminder statistics for an officer"""
    connection = None
    cursor = None
    try:
        connection = get_db_connection()
        if not connection:
            return {}
        
        cursor = connection.cursor(dictionary=True)
        
        # Total active reminders
        cursor.execute("""
            SELECT COUNT(*) as total_active 
            FROM Reminders 
            WHERE officer_id = %s AND is_resolved = FALSE
        """, (officer_id,))
        stats = cursor.fetchone()
        
        # Overdue reminders
        cursor.execute("""
            SELECT COUNT(*) as total_overdue 
            FROM Reminders 
            WHERE officer_id = %s AND is_resolved = FALSE AND due_date < NOW()
        """, (officer_id,))
        overdue = cursor.fetchone()
        
        # High priority active
        cursor.execute("""
            SELECT COUNT(*) as high_priority 
            FROM Reminders 
            WHERE officer_id = %s AND is_resolved = FALSE AND priority = 'High'
        """, (officer_id,))
        high_priority = cursor.fetchone()
        
        stats['overdue'] = overdue['total_overdue']
        stats['high_priority'] = high_priority['high_priority']
        
        return stats
        
    except Error as e:
        print(f"Error getting reminder statistics: {e}")
        return {}
    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()

def check_and_generate_recurring_reminders():
    """
    Check pending complaints and generate recurring reminders based on priority.
    - High: Every 1 hr
    - Medium: Every 2 hrs
    - Normal: Every 24 hrs (1 day)
    """
    connection = None
    cursor = None
    try:
        connection = get_db_connection()
        if not connection:
            return
        
        cursor = connection.cursor(dictionary=True)
        
        # Get all PENDING complaints
        cursor.execute("""
            SELECT complaint_id, priority, submittedAt, name, officerName, userName, inwardNo 
            FROM Complaints 
            WHERE status = 'Pending'
        """)
        pending_complaints = cursor.fetchall()
        
        current_time = datetime.now()
        
        for complaint in pending_complaints:
            comp_id = complaint['complaint_id']
            priority = complaint['priority']
            inward_no = complaint['inwardNo']
            submitted_at = complaint['submittedAt'] # datetime object
            
            # Determine interval in minutes
            if QUICK_REMINDERS:
                interval_minutes = 1
            else:
                if 'अतितात्काळ' in priority or 'High' in priority:
                    interval_minutes = REMINDER_INTERVAL_MINUTES.get('High', 60)
                elif 'तात्काळ' in priority or 'Medium' in priority:
                    interval_minutes = REMINDER_INTERVAL_MINUTES.get('Medium', 120)
                else:
                    interval_minutes = REMINDER_INTERVAL_MINUTES.get('Normal', 1440)
            
            # Check last notification time for this complaint
            # We look for 'Reminder' type notifications in OfficerNotifications 
            cursor.execute("""
                SELECT created_at FROM OfficerNotifications 
                WHERE complaint_id = %s AND title LIKE 'Recurring Reminder%'
                ORDER BY created_at DESC LIMIT 1
            """, (comp_id,))
            last_notif = cursor.fetchone()
            
            last_time = last_notif['created_at'] if last_notif else submitted_at
            
            # Calculate time difference in minutes
            diff = current_time - last_time
            diff_minutes = diff.total_seconds() / 60
            
            if diff_minutes >= interval_minutes:
                # Time to remind!
                officer_id = None
                
                # Logic to find officer
                cursor.execute("SELECT Sr_No FROM RegistrationInfo WHERE user_name = %s", (complaint['userName'],))
                res = cursor.fetchone()
                if not res:
                     cursor.execute("SELECT Sr_No FROM RegistrationInfo WHERE Name_of_Registerer = %s", (complaint['officerName'],))
                     res = cursor.fetchone()
                
                if res:
                    officer_id = res['Sr_No']
                    
                    # Create Notification
                    msg = f"Reminder: Complaint #{comp_id} (Avak No: {inward_no}) - {priority}. Please update status."
                    create_officer_notification(
                        officer_id=officer_id,
                        complaint_id=comp_id,
                        title=f"Recurring Reminder ({priority})",
                        message=msg
                    )
                    print(f"⏰ Recurring reminder sent for Complaint {comp_id} to Officer {officer_id}")
                    
    except Exception as e:
        print(f"Error in recurring check: {e}")
    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()