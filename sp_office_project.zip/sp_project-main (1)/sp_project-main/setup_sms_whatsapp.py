#!/usr/bin/env python3
"""
Setup SMS and WhatsApp Notifications
Run this to configure Twilio credentials
"""

import os
import sys

def setup_twilio():
    """Interactive setup for Twilio credentials"""
    
    print("=" * 60)
    print("📱 SMS & WhatsApp Notifications Setup")
    print("=" * 60)
    print()
    
    print("ℹ️  Before starting, get your Twilio credentials:")
    print("   1. Go to: https://www.twilio.com/console")
    print("   2. Sign up for free account")
    print("   3. Get Account SID and Auth Token")
    print("   4. Get a phone number")
    print("   5. Enable WhatsApp")
    print()
    
    # Get credentials
    account_sid = input("Enter Twilio Account SID: ").strip()
    auth_token = input("Enter Twilio Auth Token: ").strip()
    phone_number = input("Enter Twilio Phone Number (+country_code+number, e.g., +1234567890): ").strip()
    whatsapp_number = input("Enter WhatsApp Number (whatsapp:+country_code+number, e.g., whatsapp:+1234567890): ").strip()
    
    if not all([account_sid, auth_token, phone_number, whatsapp_number]):
        print("\n✗ Error: All fields are required!")
        return False
    
    # Save to environment variables
    print("\n" + "=" * 60)
    print("📝 Setting up environment variables...")
    print("=" * 60)
    print()
    
    # For Windows
    if sys.platform.startswith('win'):
        print("📌 For Windows (Command Prompt), run these commands:")
        print()
        print(f'set TWILIO_ACCOUNT_SID={account_sid}')
        print(f'set TWILIO_AUTH_TOKEN={auth_token}')
        print(f'set TWILIO_PHONE_NUMBER={phone_number}')
        print(f'set TWILIO_WHATSAPP_NUMBER={whatsapp_number}')
        print()
        print("📌 For Windows (PowerShell), run these commands:")
        print()
        print(f'$env:TWILIO_ACCOUNT_SID="{account_sid}"')
        print(f'$env:TWILIO_AUTH_TOKEN="{auth_token}"')
        print(f'$env:TWILIO_PHONE_NUMBER="{phone_number}"')
        print(f'$env:TWILIO_WHATSAPP_NUMBER="{whatsapp_number}"')
        print()
    else:
        print("📌 For Linux/Mac, run these commands:")
        print()
        print(f'export TWILIO_ACCOUNT_SID="{account_sid}"')
        print(f'export TWILIO_AUTH_TOKEN="{auth_token}"')
        print(f'export TWILIO_PHONE_NUMBER="{phone_number}"')
        print(f'export TWILIO_WHATSAPP_NUMBER="{whatsapp_number}"')
        print()
    
    # Test connection
    print("=" * 60)
    print("🧪 Testing Twilio connection...")
    print("=" * 60)
    print()
    
    try:
        from twilio.rest import Client
        
        client = Client(account_sid, auth_token)
        account = client.api.accounts.get()
        
        print("✓ Successfully connected to Twilio!")
        print(f"✓ Account: {account.friendly_name}")
        print()
        
    except Exception as e:
        print(f"✗ Connection failed: {str(e)}")
        print()
        return False
    
    # Save to file
    print("=" * 60)
    print("💾 Saving configuration...")
    print("=" * 60)
    print()
    
    # Create .env file
    env_content = f"""# Twilio SMS & WhatsApp Configuration
TWILIO_ACCOUNT_SID={account_sid}
TWILIO_AUTH_TOKEN={auth_token}
TWILIO_PHONE_NUMBER={phone_number}
TWILIO_WHATSAPP_NUMBER={whatsapp_number}
"""
    
    with open('.env', 'w') as f:
        f.write(env_content)
    
    print("✓ Saved to .env file")
    print()
    
    # Test sending
    print("=" * 60)
    print("📱 Test SMS/WhatsApp sending?")
    print("=" * 60)
    print()
    
    test_phone = input("Enter your mobile number for test (10 digits, or press Enter to skip): ").strip()
    
    if test_phone and len(test_phone) == 10:
        print(f"\n🧪 Sending test messages to {test_phone}...")
        
        try:
            # Set environment
            os.environ['TWILIO_ACCOUNT_SID'] = account_sid
            os.environ['TWILIO_AUTH_TOKEN'] = auth_token
            os.environ['TWILIO_PHONE_NUMBER'] = phone_number
            os.environ['TWILIO_WHATSAPP_NUMBER'] = whatsapp_number
            
            # Import and test
            from sms_whatsapp import test_all_notifications
            result = test_all_notifications(test_phone)
            
            print("\n✓ Test completed!")
            print(f"Results: {result['summary']}")
            print()
            
        except Exception as e:
            print(f"\n✗ Test failed: {str(e)}")
            print()
    
    print("=" * 60)
    print("✅ Setup Complete!")
    print("=" * 60)
    print()
    print("Next steps:")
    print("1. Set environment variables (commands above)")
    print("2. Restart Flask: python app.py")
    print("3. Add SMS/WhatsApp to complaint submission code")
    print("4. Deploy!")
    print()
    print("📖 Read SMS_WHATSAPP_GUIDE.md for more details")
    print()
    
    return True

if __name__ == '__main__':
    # Check if twilio is installed
    try:
        import twilio
    except ImportError:
        print("❌ Twilio not installed!")
        print("Run: pip install twilio")
        sys.exit(1)
    
    # Run setup
    success = setup_twilio()
    sys.exit(0 if success else 1)
