#!/usr/bin/env python
# -*- coding: utf-8 -*-
import requests
import json

try:
    response = requests.get('http://localhost:5000/api/complaints-by-officer')
    print(f"Status Code: {response.status_code}")
    print(f"\nResponse:")
    data = response.json()
    print(json.dumps(data, indent=2, ensure_ascii=False))
except Exception as e:
    print(f"Error: {e}")
