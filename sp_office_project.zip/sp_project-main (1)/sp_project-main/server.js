// Node.js Server for Login & Registration System
const express = require('express');
const cors = require('cors');
const path = require('path');
const db = require('./db-config');
const registrationRoute = require('./routes/register');

const app = express();
const PORT = 3000;

// Middleware
app.use(cors()); // Enable CORS for all routes
app.use(express.json()); // Parse JSON bodies
app.use(express.urlencoded({ extended: true })); // Parse URL-encoded bodies

// Serve static files (HTML, CSS, JS) from current directory
app.use(express.static(path.join(__dirname)));

// API Routes
app.use('/api', registrationRoute);

// Serve the HTML files
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

app.get('/Registration.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'Registration.html'));
});

app.get('/Login.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'Login.html'));
});

// Start server
app.listen(PORT, () => {
    console.log(`🚀 Server is running on http://localhost:${PORT}`);
    console.log(`📝 Registration page: http://localhost:${PORT}/Registration.html`);
    console.log(`🔐 Login page: http://localhost:${PORT}/Login.html`);
});

// Handle server errors
process.on('unhandledRejection', (err) => {
    console.error('Unhandled Promise Rejection:', err);
});

