# तक्रार व्यवस्थापन प्रणाली (Complaint Management System)

## System Overview

This is a centralized complaint management system exclusively for **Officers** (अधिकारी). Citizens (नागरिक) are **NOT** allowed to register or log in.

### Key Features

✅ **Officer-Only System**
- Only authorized officers can register and log in
- Citizens cannot access the system
- All users are treated as officers

✅ **Complaint Management**
- Officers can file complaints on behalf of citizens
- View all complaints filed by any officer (centralized view)
- Display complete complaint details including officer information
- Update complaint status (Pending/Solved)

✅ **Dashboard & Analytics**
- Statistics showing total, pending, and solved complaints
- Filter complaints by name, mobile number, or status
- Real-time status updates

✅ **Secure System**
- User authentication with username and password
- Session management
- Database validation and error handling

---

## System Architecture

### Technology Stack
- **Frontend**: HTML5, CSS3, JavaScript (Marathi UI)
- **Backend**: Flask (Python)
- **Database**: MySQL
- **Libraries**: Bootstrap 5, Flatpickr (Date picker)

### Database Schema

#### RegistrationInfo Table
```
Sr_No               INT (Primary Key, Auto-increment)
Name_of_Registerer  VARCHAR(50)
Address             VARCHAR(100)
Date_of_birth       DATE
Mobile_Number       VARCHAR(10) UNIQUE
Email               VARCHAR(100)
user_name           VARCHAR(20) UNIQUE
Password            VARCHAR(255)
officer_role        VARCHAR(20) DEFAULT 'officer' ← NEW
created_at          TIMESTAMP
```

#### Complaints Table
```
complaint_id        INT (Primary Key, Auto-increment)
sr_no              INT
inwardNo           VARCHAR(50)
name               VARCHAR(100)
mobile             VARCHAR(10)
address            TEXT
reason             TEXT
date               VARCHAR(50)
district           VARCHAR(100)
deptSent           VARCHAR(10)
priority           VARCHAR(50)
status             VARCHAR(20) DEFAULT 'Pending' ← NEW
submittedAt        DATETIME
userName           VARCHAR(50) FOREIGN KEY
```

---

## Setup Instructions

### 1. Prerequisites
- Python 3.8+
- MySQL Server 5.7+
- Flask and mysql-connector-python

### 2. Install Dependencies
```bash
pip install flask flask-cors mysql-connector-python
```

### 3. Database Setup

#### Option A: Fresh Installation
```bash
# Run the database initialization
python db.py
```

#### Option B: Existing Database (Run Migration)
```bash
# This will add missing columns to existing tables
python migrate_db.py
```

### 4. Update Database Configuration

Edit `app.py` and `db.py` to match your MySQL credentials:
```python
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': 'root',      # Change this to your MySQL password
    'database': 'spdata',      # Create this database in MySQL
    'port': 3407
}
```

### 5. Create Database (if not exists)
```sql
CREATE DATABASE spdata;
USE spdata;
```

### 6. Run the Application
```bash
python app.py
```

The application will be available at: `http://localhost:5000`

---

## User Workflows

### 1. Officer Registration
1. Navigate to Registration page
2. Fill in all required details:
   - Full Name
   - Address
   - Date of Birth
   - Mobile Number
   - Email
   - Username (3-20 characters, alphanumeric + underscore)
   - Password
3. System automatically assigns **Officer role**
4. Redirect to Login page

### 2. Officer Login
1. Navigate to Login page
2. Enter username and password
3. System verifies:
   - Credentials are correct
   - User has "officer" role
   - If citizen, login is blocked
4. Redirect to Complaint Management Dashboard

### 3. File a Complaint
1. Click "नवीन तक्रार नोंदणी" (New Complaint)
2. Fill complaint details:
   - Inward Number (Complaint ID)
   - Date
   - Complainant Name
   - Mobile Number
   - Address
   - Reason for complaint
   - District
   - Priority level
   - Department sent to?
3. Submit
4. System generates complaint ID and stores in database
5. Auto-redirect to view all complaints

### 4. View All Complaints
1. Click "सर्व तक्रारा पहा" (View All Complaints)
2. See statistics:
   - Total complaints
   - Pending complaints
   - Solved complaints
3. Filter by:
   - Complainant name
   - Mobile number
   - Status (Pending/Solved)
4. View complete information:
   - Complaint details
   - Filing officer's name and contact
   - Current status
   - Submission timestamp

### 5. Update Complaint Status
1. In complaint list, click "अपडेट" (Update) button
2. Confirm status change to:
   - "Pending" ↔ "Solved"
3. System updates database and refreshes list

### 6. Delete Complaint
1. Click "हटवा" (Delete) button
2. Confirm deletion
3. Complaint removed from database

---

## API Endpoints

### Authentication
- `POST /api/register` - Officer registration
- `POST /api/login` - Officer login
- `POST /api/admin-login` - Admin login

### Complaints
- `POST /api/save-complaint` - File a new complaint
- `GET /api/get-all-complaints` - Retrieve all complaints (with officer details)
- `GET /api/get-complaints?mobile=XXXX` - Get complaints by mobile number (legacy)
- `PUT /api/update-complaint-status/<id>` - Update complaint status
- `DELETE /api/delete-complaint/<id>` - Delete a complaint

### Registration
- `GET /api/view-registrations` - View all registered officers

### System
- `GET /api/health` - Check database connection

---

## File Structure

```
sp_project/
├── app.py                      # Main Flask application
├── db.py                       # Database configuration & schema
├── migrate_db.py               # Database migration script
├── Login.html                  # Officer login page
├── Login.js                    # Login form handler
├── Login.css                   # Login styling
├── Registration.html           # Officer registration page
├── Registration.js             # Registration form handler
├── Registration.css            # Registration styling
├── CaseFile.html               # Complaint management dashboard
├── AdminPanel.html             # Admin panel
├── AdminLogin.html             # Admin login
├── assets/                     # Images and assets
│   ├── sp_logo.jpg
│   └── favicon.svg
└── README.md                   # This file
```

---

## Important Changes Made

### 1. Database Configuration Fixed
- **Before**: app.py used `spdata` on port 3407, db.py used `spdata1` on default port
- **After**: Both files now use `spdata` on port 3306 (standard MySQL port)

### 2. Officer Role Added
- New column `officer_role` in RegistrationInfo table
- All registrations default to 'officer'
- Login validates officer role before granting access

### 3. Complaint Status Tracking
- New column `status` in Complaints table
- Values: 'Pending' (default) or 'Solved'
- Officers can update status for any complaint

### 4. Collective Complaint Viewing
- `/api/get-all-complaints` endpoint returns complaints from **all officers**
- Includes officer name and mobile number with each complaint
- Not restricted to individual officer's complaints

### 5. Enhanced UI
- New "सर्व तक्रारा पहा" (View All Complaints) tab
- Statistics dashboard showing complaint status breakdown
- Filter functionality by name, mobile, or status
- Status badges (Color-coded: Yellow for Pending, Green for Solved)
- Responsive design for mobile devices

---

## Testing Checklist

- [ ] Create officer account with all required fields
- [ ] Login with officer credentials
- [ ] Verify citizen/non-officer cannot login
- [ ] File a complaint successfully
- [ ] View all complaints including those from other officers
- [ ] Verify officer name appears in complaint list
- [ ] Update complaint status from Pending to Solved
- [ ] Filter complaints by name
- [ ] Filter complaints by mobile number
- [ ] Filter complaints by status
- [ ] Delete a complaint
- [ ] Logout and verify session cleared
- [ ] Check mobile responsiveness
- [ ] Test with database errors (restart MySQL and verify error handling)

---

## Security Notes

⚠️ **For Production Deployment:**
1. Change default admin credentials in app.py
2. Hash passwords using bcrypt (not plain text)
3. Implement SSL/TLS for data transmission
4. Add CSRF protection
5. Implement rate limiting
6. Add audit logging for complaint modifications
7. Restrict access with role-based permissions
8. Use environment variables for sensitive data

---

## Troubleshooting

### Database Connection Error
```
Error: "Can't connect to MySQL server"
```
**Solution:**
1. Verify MySQL is running: `mysql -u root -p`
2. Check database name and credentials in app.py
3. Ensure database exists: `CREATE DATABASE spdata;`

### Officer Role Error
```
Error: "Only officers can login"
```
**Solution:**
1. Run migration script: `python migrate_db.py`
2. Verify officer_role column added to RegistrationInfo
3. Check existing data: `SELECT * FROM RegistrationInfo;`

### Status Column Missing
```
Error: "Unknown column 'status'"
```
**Solution:**
1. Run migration script: `python migrate_db.py`
2. This will add the status column to Complaints table

### Port Already in Use
```
Error: "Address already in use"
```
**Solution:**
1. Change port in app.py: `app.run(port=5001)`
2. Or kill existing process on port 5000

---

## Support & Contact

For issues or questions about the system:
1. Check database configuration matches your MySQL setup
2. Verify all required tables exist with correct schema
3. Run migration script if columns are missing
4. Check browser console for JavaScript errors
5. Review Flask server logs for backend errors

---

## License

This project is confidential and for authorized use only.

**Last Updated:** January 23, 2026
**System Version:** 1.0 (Officer-Only Release)
