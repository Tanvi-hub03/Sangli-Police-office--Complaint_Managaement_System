        // Display officer-wise statistics
        function displayOfficerStats(complaints) {
            const container = document.getElementById('officerStatsContainer');
            
            // Group complaints by officer
            const officerStats = {};
            complaints.forEach(complaint => {
                const officer = complaint.officer_name || 'असाइन नाही';
                if (!officerStats[officer]) {
                    officerStats[officer] = { total: 0, resolved: 0, pending: 0 };
                }
                officerStats[officer].total++;
                if (complaint.status === 'Resolved') {
                    officerStats[officer].resolved++;
                } else {
                    officerStats[officer].pending++;
                }
            });
            
            let html = '';
            Object.keys(officerStats).forEach(officer => {
                const stats = officerStats[officer];
                html += `
                    <div class="officer-card">
                        <div class="officer-name">${officer}</div>
                        <div class="officer-stats">
                            <div class="officer-stat total">📋 एकूण: ${stats.total}</div>
                            <div class="officer-stat resolved">✅ सोडवलेले: ${stats.resolved}</div>
                            <div class="officer-stat pending">⏳ प्रलंबित: ${stats.pending}</div>
                        </div>
                    </div>
                `;
            });
            
            container.innerHTML = html;
        }