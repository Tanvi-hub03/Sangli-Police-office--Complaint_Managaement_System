# 📱 SMS & WhatsApp Notifications - Integration Guide

## ✅ What You Can Do Now

Citizens will get **automatic SMS + WhatsApp** notifications when:
- ✅ Complaint registered
- ✅ Complaint status updated
- ✅ Complaint resolved

---

## 🚀 SETUP (5 Steps)

### Step 1: Get Twilio Account
1. Go to: https://www.twilio.com/console
2. Sign up for free account
3. Get your **Account SID** and **Auth Token**
4. Get a **phone number** (for SMS)
5. Enable **WhatsApp** on your Twilio account

### Step 2: Install Twilio
```bash
pip install twilio
```

### Step 3: Set Environment Variables
**Windows (Command Prompt):**
```cmd
set TWILIO_ACCOUNT_SID=ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
set TWILIO_AUTH_TOKEN=your_auth_token_here
set TWILIO_PHONE_NUMBER=+1234567890
set TWILIO_WHATSAPP_NUMBER=whatsapp:+1234567890
```

**Windows (PowerShell):**
```powershell
$env:TWILIO_ACCOUNT_SID="ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
$env:TWILIO_AUTH_TOKEN="your_auth_token_here"
$env:TWILIO_PHONE_NUMBER="+1234567890"
$env:TWILIO_WHATSAPP_NUMBER="whatsapp:+1234567890"
```

**Linux/Mac:**
```bash
export TWILIO_ACCOUNT_SID="ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
export TWILIO_AUTH_TOKEN="your_auth_token_here"
export TWILIO_PHONE_NUMBER="+1234567890"
export TWILIO_WHATSAPP_NUMBER="whatsapp:+1234567890"
```

### Step 4: Restart Flask
```bash
python app.py
```

### Step 5: Test It!
```python
python -c "from sms_whatsapp import test_all_notifications; test_all_notifications('9876543210')"
```

---

## 💻 INTEGRATION INTO YOUR CODE

### Option 1: Send All (SMS + WhatsApp + Database)
```python
from sms_whatsapp import send_all_notifications

# When complaint is created:
message_data = {
    'short': 'आपली तक्रार #123 नोंदवली गेली',
    'long': 'नमस्कार Raj! आपली तक्रार यशस्वीरित्या नोंदवली गेली. तक्रार क्रमांक: #123'
}

results = send_all_notifications(
    mobile_number='9876543210',
    message_data=message_data,
    complaint_id=123,
    use_sms=True,
    use_whatsapp=True,
    use_database=True
)

print(results['summary'])
# Output: {'total_channels': 3, 'successfully_sent': 3, 'status': 'success'}
```

### Option 2: WhatsApp Only
```python
from sms_whatsapp import send_whatsapp_complaint_registered

result = send_whatsapp_complaint_registered(
    mobile_number='9876543210',
    complaint_id=123,
    citizen_name='Raj Kumar'
)
print(result)
```

### Option 3: SMS Only
```python
from sms_whatsapp import send_sms_complaint_registered

result = send_sms_complaint_registered(
    mobile_number='9876543210',
    complaint_id=123,
    citizen_name='Raj Kumar'
)
print(result)
```

---

## 🔄 COMPLETE INTEGRATION EXAMPLE

In your `app.py`, after complaint creation:

```python
from sms_whatsapp import send_all_notifications

@app.route('/api/submit-complaint', methods=['POST'])
def submit_complaint():
    # ... your existing code ...
    
    # After inserting complaint into database:
    complaint_id = cursor.lastrowid
    mobile_number = data.get('mobile')
    citizen_name = data.get('name')
    
    # Send SMS + WhatsApp + Save to Database
    message_data = {
        'short': f'आपली तक्रार #{complaint_id} नोंदवली गेली',
        'long': f'''नमस्कार {citizen_name}! 🎯

आपली तक्रार यशस्वीरित्या नोंदवली गेली!

📋 तक्रार क्रमांक: #{complaint_id}
⏰ नोंदवले: {datetime.now().strftime('%d/%m/%Y %H:%M')}

आपले तक्रार शीघ्रच पाहिले जाईल आणि आपणास अद्यतन दिले जाईल.

धन्यवाद! 🙏'''
    }
    
    results = send_all_notifications(
        mobile_number=mobile_number,
        message_data=message_data,
        complaint_id=complaint_id
    )
    
    return jsonify({
        'success': True,
        'complaint_id': complaint_id,
        'notifications_sent': results['summary']
    }), 201
```

---

## 📊 WHAT CITIZENS RECEIVE

### SMS Format:
```
नमस्कार Raj! आपली तक्रार #123 यशस्वीरित्या नोंदवली गेली. लवकरच अद्यतन मिळेल.
```

### WhatsApp Format:
```
नमस्कार Raj! 🎯

आपली तक्रार यशस्वीरित्या नोंदवली गेली!

📋 तक्रार क्रमांक: #123
⏰ नोंदवले: 23/01/2026 14:30

आपले तक्रार शीघ्रच पाहिले जाईल आणि आपणास अद्यतन दिले जाईल.

धन्यवाद! 🙏
```

---

## 🎯 WHEN TO SEND NOTIFICATIONS

### 1. Complaint Registered
```python
send_whatsapp_complaint_registered(mobile, complaint_id, name)
send_sms_complaint_registered(mobile, complaint_id, name)
```

### 2. Complaint Status Updated
```python
send_whatsapp_complaint_updated(mobile, complaint_id, name, new_status)
send_sms_complaint_updated(mobile, complaint_id, name, new_status)
```

### 3. Complaint Resolved
```python
send_whatsapp_complaint_resolved(mobile, complaint_id, name)
send_sms_complaint_resolved(mobile, complaint_id, name)
```

---

## 🔌 API ENDPOINTS (Optional)

Add these to `app.py` if needed:

```python
@app.route('/api/send-test-sms/<mobile>', methods=['POST'])
def send_test_sms(mobile):
    from sms_whatsapp import send_sms_notification
    result = send_sms_notification(mobile, 'Test SMS from complaint system')
    return jsonify(result)

@app.route('/api/send-test-whatsapp/<mobile>', methods=['POST'])
def send_test_whatsapp(mobile):
    from sms_whatsapp import send_whatsapp_notification
    result = send_whatsapp_notification(mobile, 'Test WhatsApp from complaint system')
    return jsonify(result)
```

---

## 📱 Twilio Pricing (Free Tier)

| Feature | Free Tier |
|---------|-----------|
| SMS | $0.0075 per SMS (after trial credits) |
| WhatsApp | Free until production (then $0.005 per message) |
| Trial Credits | $15 (lasts ~1-2 weeks) |
| No Credit Card | Required for signup |

**India SMS:** ~₹0.50 per SMS  
**Indian WhatsApp:** ~₹0.40 per message

---

## ✅ TESTING FUNCTIONS

### Test SMS
```bash
python -c "from sms_whatsapp import test_sms_notification; test_sms_notification('9876543210')"
```

### Test WhatsApp
```bash
python -c "from sms_whatsapp import test_whatsapp_notification; test_whatsapp_notification('9876543210')"
```

### Test Both
```bash
python -c "from sms_whatsapp import test_all_notifications; test_all_notifications('9876543210')"
```

---

## 🔍 CHECK TWILIO STATUS

```python
from sms_whatsapp import get_twilio_status

status = get_twilio_status()
print(status)

# Output:
# {
#     'twilio_available': True,
#     'configured': True,
#     'account_sid': 'ACxxxxxxxx...',
#     'phone_number': '+1234567890',
#     'whatsapp_number': 'whatsapp:+1234567890'
# }
```

---

## 🆘 TROUBLESHOOTING

| Issue | Solution |
|-------|----------|
| "Twilio not installed" | `pip install twilio` |
| "Twilio not configured" | Set environment variables (Step 3) |
| SMS fails with error | Check phone number format (+country_code) |
| WhatsApp fails | Ensure WhatsApp is enabled in Twilio |
| No message received | Check mobile number format (10 digits for India) |
| Getting 400 error | Verify credentials are correct |
| SMS cut off | Messages longer than 160 chars are split (costs 2 SMS) |

---

## 📊 INTEGRATION CHECKLIST

- [ ] Created Twilio account
- [ ] Got Account SID & Auth Token
- [ ] Got phone number
- [ ] Enabled WhatsApp on Twilio
- [ ] Installed Twilio: `pip install twilio`
- [ ] Set environment variables
- [ ] Restarted Flask
- [ ] Tested SMS and WhatsApp
- [ ] Added code to complaint creation
- [ ] Added code to status update
- [ ] Added code to resolution
- [ ] Tested end-to-end flow
- [ ] Ready for production

---

## 💡 BEST PRACTICES

1. **Test First** - Use test phone numbers before going live
2. **Monitor Costs** - Track SMS/WhatsApp usage
3. **Rate Limit** - Don't send too many messages at once
4. **Error Handling** - Always check response status
5. **Log Messages** - Keep record of all sent messages
6. **Timezone** - Show correct time in messages
7. **Language** - Use Marathi for local citizens
8. **Opt-out** - Provide option to disable notifications

---

## 🎯 NEXT STEPS

1. Get Twilio account
2. Set environment variables
3. Run: `python -c "from sms_whatsapp import test_all_notifications; test_all_notifications('9876543210')"`
4. Check your phone for SMS + WhatsApp
5. Add to complaint submission code
6. Deploy!

---

## 📞 SUPPORT

For Twilio support: https://support.twilio.com/

For this implementation: Check INTEGRATION_EXAMPLES.py

---

**SMS/WhatsApp Notifications are Ready! 🚀**
