import mysql.connector

def get_db_connection():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database="spdata",
        port=3407
    )

def create_registration_table():
    """Create RegistrationInfo table"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS RegistrationInfo(
            Sr_No INT AUTO_INCREMENT PRIMARY KEY,
            Name_of_Registerer VARCHAR(50) NOT NULL,
            Address VARCHAR(100) NOT NULL,
            Date_of_birth DATE NOT NULL,
            Mobile_Number VARCHAR(10) NOT NULL,
            user_name VARCHAR(20) NOT NULL UNIQUE,
            Password VARCHAR(255) NOT NULL,
            Email VARCHAR(100) NOT NULL,
            officer_role VARCHAR(20) DEFAULT 'officer',
            district VARCHAR(100),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    
    conn.commit()
    cursor.close()
    conn.close()
    print("RegistrationInfo table created successfully!")

def create_complaint_table():
    """Create Complaints table"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS Complaints (
            complaint_id INT PRIMARY KEY AUTO_INCREMENT,
            sr_no INT NOT NULL,
            inwardNo VARCHAR(50) NOT NULL,
            name VARCHAR(100) NOT NULL,
            mobile VARCHAR(10) NOT NULL,
            address TEXT,
            reason TEXT,
            date VARCHAR(50),
            district VARCHAR(100),
            deptSent VARCHAR(10),
            priority VARCHAR(50),
            status VARCHAR(20) DEFAULT 'Pending',
            submittedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
            userName VARCHAR(50),
            officerName VARCHAR(100),
            INDEX idx_mobile (mobile),
            INDEX idx_sr_no (sr_no),
            INDEX idx_status (status)
        )
    """)
    
    conn.commit()
    cursor.close()
    conn.close()
    print("Complaints table created successfully!")

def create_officer_notifications_table():
    """Create OfficerNotifications table"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS OfficerNotifications (
            notification_id INT AUTO_INCREMENT PRIMARY KEY,
            officer_id INT NOT NULL,
            complaint_id INT,
            title VARCHAR(100) NOT NULL,
            message TEXT NOT NULL,
            is_read BOOLEAN DEFAULT FALSE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (officer_id) REFERENCES RegistrationInfo(Sr_No),
            FOREIGN KEY (complaint_id) REFERENCES Complaints(complaint_id)
        )
    """)
    
    conn.commit()
    cursor.close()
    conn.close()
    print("OfficerNotifications table created successfully!")

def initialize_tables():
    """Initialize all tables"""
    create_registration_table()
    create_complaint_table()
    create_officer_notifications_table()
    print("All tables initialized!")
