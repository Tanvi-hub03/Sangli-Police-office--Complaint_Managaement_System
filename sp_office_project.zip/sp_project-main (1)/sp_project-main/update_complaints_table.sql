-- Update Complaints table to add new columns for detailed updates
ALTER TABLE Complaints
ADD COLUMN IF NOT EXISTS acceptance_method VARCHAR(20) DEFAULT NULL,
ADD COLUMN IF NOT EXISTS update_date VARCHAR(20) DEFAULT NULL,
ADD COLUMN IF NOT EXISTS updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;

-- Update existing records to have a default status if not present
ALTER TABLE Complaints
ADD COLUMN IF NOT EXISTS status VARCHAR(20) DEFAULT 'Pending';

-- Update inwardNo to allow NULL for backward compatibility
ALTER TABLE Complaints
MODIFY COLUMN inwardNo VARCHAR(50) DEFAULT NULL;