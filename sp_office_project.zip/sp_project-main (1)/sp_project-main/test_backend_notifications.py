import requests
import json
import time

BASE_URL = "http://localhost:5000"

def test_signup_officer():
    print("\n[1] Testing Officer Registration...")
    officer_data = {
        "fullName": "Test Officer 99",
        "address": "Police HQ",
        "dateOfBirth": "1990-01-01",
        "mobileNumber": "9999999999",
        "email": "testoff99@example.com",
        "username": "officer99",
        "password": "password123",
        "district": "Sangli"
    }
    
    # Try signup (might fail if already exists, which is fine)
    try:
        resp = requests.post(f"{BASE_URL}/api/register", json=officer_data)
        print(f"Signup Status: {resp.status_code}")
        if resp.status_code == 200 or "already exists" in resp.text:
            print("Signup or Pre-check Passed.")
            return True
    except Exception as e:
        print(f"Signup Failed: {e}")
        return False
    return False

def test_login_officer():
    print("\n[2] Testing Officer Login & Getting ID...")
    login_data = {
        "username": "officer99",
        "password": "password123"
    }
    try:
        resp = requests.post(f"{BASE_URL}/api/login", json=login_data)
        if resp.status_code == 200:
            data = resp.json()
            user = data['user']
            print(f"Login Success! Officer ID: {user['sr_no']}, Name: {user['name']}")
            return user['sr_no'], user['name']
        else:
            print(f"Login Failed: {resp.text}")
            return None, None
    except Exception as e:
        print(f"Login Error: {e}")
        return None, None

def test_create_complaint(officer_name, officer_username):
    print("\n[3] Creating Complaint Assigned to Officer...")
    complaint_data = {
        "sr_no": 999, # Dummy citizen ID
        "inwardNo": "INW-TEST-99",
        "name": "Citizen Test",
        "mobile": "8888888888",
        "address": "Test Address",
        "reason": "Test Complaint",
        "date": "2024-01-01",
        "district": "Sangli",
        "deptSent": "Police",
        "priority": "High",
        "userName": officer_username, # User who logged in/created it (also checking notification for them is weird but per logic)
        "officerName": officer_name   # Targeted officer
    }
    
    try:
        resp = requests.post(f"{BASE_URL}/api/save-complaint", json=complaint_data)
        if resp.status_code == 201:
            data = resp.json()
            cid = data['complaint_id']
            print(f"Complaint Created! ID: {cid}")
            return cid
        else:
            print(f"Complaint Creation Failed: {resp.text}")
            return None
    except Exception as e:
        print(f"Complaint Error: {e}")
        return None

def test_check_notifications(officer_id):
    print(f"\n[4] Checking Notifications for Officer ID {officer_id}...")
    try:
        resp = requests.get(f"{BASE_URL}/api/officer-notifications/{officer_id}")
        if resp.status_code == 200:
            data = resp.json()
            notifs = data['notifications']
            print(f"Found {len(notifs)} unread notifications.")
            for n in notifs:
                print(f" - [{n['notification_id']}] {n['title']}: {n['message']}")
            return notifs
        else:
            print(f"Get Notifications Failed: {resp.text}")
            return []
    except Exception as e:
        print(f"Get Notifications Error: {e}")
        return []

def run_test():
    test_signup_officer()
    officer_id, officer_name = test_login_officer()
    
    if officer_id:
        # Create complaint
        cid = test_create_complaint(officer_name, "officer99")
        
        if cid:
            # Check for notification
            time.sleep(1) # Wait for async operations (though ours are sync now)
            notifs = test_check_notifications(officer_id)
            
            # Verify "New Complaint Assigned" exists
            found = any(n['complaint_id'] == cid and "Assigned" in n['title'] for n in notifs)
            if found:
                print("✅ Test Passed: 'New Complaint Assigned' notification received!")
            else:
                print("❌ Test Failed: Notification not found.")

if __name__ == "__main__":
    run_test()
