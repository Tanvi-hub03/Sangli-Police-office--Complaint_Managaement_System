-- SQL script to update the RegistrationIfo table structure
-- Run this if your table was created with the original structure

USE SPDATA;

-- Option 1: If you want to keep your existing table and just modify Mobile_Number
-- Uncomment the line below to change Mobile_Number from INT to VARCHAR(10)
-- ALTER TABLE RegistrationIfo MODIFY COLUMN Mobile_Number VARCHAR(10);

-- Option 2: If you want to recreate the table with better structure (WARNING: This will delete all existing data!)
-- DROP TABLE IF EXISTS RegistrationIfo;

-- Create table with improved structure
CREATE TABLE IF NOT EXISTS RegistrationIfo(
    Sr_No INT AUTO_INCREMENT PRIMARY KEY,
    Name_of_Registerer VARCHAR(50) NOT NULL,  -- Increased from 20 to 50 for longer names
    Address VARCHAR(100) NOT NULL,
    Date_of_birth DATE NOT NULL,
    Mobile_Number VARCHAR(10) NOT NULL,  -- Changed to VARCHAR to preserve leading zeros
    user_name VARCHAR(20) NOT NULL UNIQUE,  -- Added UNIQUE constraint
    Password VARCHAR(255) NOT NULL,  -- Increased size for hashed passwords (if you plan to hash)
    Email VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP -- Optional: track registration time
);

-- Verify the table structure
DESCRIBE RegistrationIfo;
