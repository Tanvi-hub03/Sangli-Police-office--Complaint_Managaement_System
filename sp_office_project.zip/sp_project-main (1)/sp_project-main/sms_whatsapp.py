"""
SMS and WhatsApp Notifications Module
Uses Twilio to send SMS and WhatsApp messages to citizens
"""

import os
from datetime import datetime

# Import Twilio
try:
    from twilio.rest import Client
    TWILIO_AVAILABLE = True
except ImportError:
    TWILIO_AVAILABLE = False
    print("⚠️  Twilio not installed. Run: pip install twilio")

# ============================================================================
# TWILIO CONFIGURATION
# ============================================================================

# Set your Twilio credentials here or use environment variables
TWILIO_ACCOUNT_SID = os.getenv('TWILIO_ACCOUNT_SID', 'your_account_sid')
TWILIO_AUTH_TOKEN = os.getenv('TWILIO_AUTH_TOKEN', 'your_auth_token')
TWILIO_PHONE_NUMBER = os.getenv('TWILIO_PHONE_NUMBER', '+1234567890')  # SMS number
TWILIO_WHATSAPP_NUMBER = os.getenv('TWILIO_WHATSAPP_NUMBER', 'whatsapp:+1234567890')  # WhatsApp

# Initialize Twilio client (only if credentials are set)
if TWILIO_AVAILABLE and TWILIO_ACCOUNT_SID != 'your_account_sid':
    twilio_client = Client(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)
else:
    twilio_client = None

# ============================================================================
# SMS NOTIFICATIONS
# ============================================================================

def send_sms_notification(mobile_number, message, complaint_id=None):
    """
    Send SMS notification to citizen
    
    Args:
        mobile_number: Citizen's 10-digit mobile number (without country code)
        message: SMS message text
        complaint_id: Optional complaint ID for logging
    
    Returns:
        dict: {success: bool, message_sid: str or None, error: str or None}
    
    Example:
        send_sms_notification('9876543210', 'Your complaint #123 has been registered')
    """
    
    if not twilio_client:
        return {
            'success': False,
            'message_sid': None,
            'error': 'Twilio not configured. Set TWILIO_ACCOUNT_SID and TWILIO_AUTH_TOKEN'
        }
    
    try:
        # Convert Indian mobile to international format
        if len(mobile_number) == 10:
            international_number = f'+91{mobile_number}'
        else:
            international_number = mobile_number
        
        # Truncate message to 160 characters (SMS limit)
        sms_message = message[:160]
        
        # Send SMS
        msg = twilio_client.messages.create(
            body=sms_message,
            from_=TWILIO_PHONE_NUMBER,
            to=international_number
        )
        
        print(f"✓ SMS sent to {mobile_number} (ID: {msg.sid})")
        
        return {
            'success': True,
            'message_sid': msg.sid,
            'error': None,
            'timestamp': datetime.now().isoformat()
        }
        
    except Exception as e:
        error_msg = f"SMS sending failed: {str(e)}"
        print(f"✗ {error_msg}")
        return {
            'success': False,
            'message_sid': None,
            'error': error_msg,
            'timestamp': datetime.now().isoformat()
        }

def send_sms_complaint_registered(mobile_number, complaint_id, citizen_name):
    """Send SMS when complaint is registered"""
    message = f"नमस्कार {citizen_name}! आपली तक्रार #{complaint_id} यशस्वीरित्या नोंदवली गेली. लवकरच अद्यतन मिळेल."
    return send_sms_notification(mobile_number, message, complaint_id)

def send_sms_complaint_updated(mobile_number, complaint_id, citizen_name, new_status):
    """Send SMS when complaint status is updated"""
    message = f"नमस्कार {citizen_name}! आपल्या तक्रार #{complaint_id} ची स्थिती अद्यतन झाली: {new_status}"
    return send_sms_notification(mobile_number, message, complaint_id)

def send_sms_complaint_resolved(mobile_number, complaint_id, citizen_name):
    """Send SMS when complaint is resolved"""
    message = f"नमस्कार {citizen_name}! आपली तक्रार #{complaint_id} सुटली गेली. धन्यवाद!"
    return send_sms_notification(mobile_number, message, complaint_id)

# ============================================================================
# WHATSAPP NOTIFICATIONS
# ============================================================================

def send_whatsapp_notification(mobile_number, message, complaint_id=None):
    """
    Send WhatsApp notification to citizen
    
    Args:
        mobile_number: Citizen's 10-digit mobile number (without country code)
        message: WhatsApp message text
        complaint_id: Optional complaint ID for logging
    
    Returns:
        dict: {success: bool, message_sid: str or None, error: str or None}
    
    Example:
        send_whatsapp_notification('9876543210', 'Your complaint #123 has been registered')
    """
    
    if not twilio_client:
        return {
            'success': False,
            'message_sid': None,
            'error': 'Twilio not configured. Set TWILIO_ACCOUNT_SID and TWILIO_AUTH_TOKEN'
        }
    
    try:
        # Convert Indian mobile to WhatsApp format
        if len(mobile_number) == 10:
            whatsapp_number = f'whatsapp:+91{mobile_number}'
        else:
            whatsapp_number = f'whatsapp:{mobile_number}'
        
        # Send WhatsApp message
        msg = twilio_client.messages.create(
            body=message,
            from_=TWILIO_WHATSAPP_NUMBER,
            to=whatsapp_number
        )
        
        print(f"✓ WhatsApp sent to {mobile_number} (ID: {msg.sid})")
        
        return {
            'success': True,
            'message_sid': msg.sid,
            'error': None,
            'timestamp': datetime.now().isoformat()
        }
        
    except Exception as e:
        error_msg = f"WhatsApp sending failed: {str(e)}"
        print(f"✗ {error_msg}")
        return {
            'success': False,
            'message_sid': None,
            'error': error_msg,
            'timestamp': datetime.now().isoformat()
        }

def send_whatsapp_complaint_registered(mobile_number, complaint_id, citizen_name):
    """Send WhatsApp when complaint is registered"""
    message = f"""नमस्कार {citizen_name}! 🎯

आपली तक्रार यशस्वीरित्या नोंदवली गेली!

📋 तक्रार क्रमांक: #{complaint_id}
⏰ नोंदवले: {datetime.now().strftime('%d/%m/%Y %H:%M')}

आपले तक्रार शीघ्रच पाहिले जाईल आणि आपणास अद्यतन दिले जाईल.

धन्यवाद! 🙏"""
    return send_whatsapp_notification(mobile_number, message, complaint_id)

def send_whatsapp_complaint_updated(mobile_number, complaint_id, citizen_name, new_status):
    """Send WhatsApp when complaint status is updated"""
    message = f"""नमस्कार {citizen_name}! 🔔

आपल्या तक्रार #{complaint_id} ची स्थिती अद्यतन झाली!

📊 नई स्थिती: {new_status}
⏰ अद्यतन वेळ: {datetime.now().strftime('%d/%m/%Y %H:%M')}

अधिक तपशीलांसाठी कृपया पोर्टलला भेट द्या.

धन्यवाद! 🙏"""
    return send_whatsapp_notification(mobile_number, message, complaint_id)

def send_whatsapp_complaint_resolved(mobile_number, complaint_id, citizen_name):
    """Send WhatsApp when complaint is resolved"""
    message = f"""नमस्कार {citizen_name}! ✅

आपली तक्रार सुटली गेली!

📋 तक्रार क्रमांक: #{complaint_id}
✅ स्थिती: सुटली गेली
⏰ सुटणे: {datetime.now().strftime('%d/%m/%Y %H:%M')}

आमच्या सेवा वापरल्याबद्दल धन्यवाद! 🙏"""
    return send_whatsapp_notification(mobile_number, message, complaint_id)

# ============================================================================
# COMBINED NOTIFICATIONS (SMS + WhatsApp)
# ============================================================================

def send_dual_notification(mobile_number, sms_msg, whatsapp_msg, complaint_id=None):
    """
    Send both SMS and WhatsApp notifications
    
    Returns:
        dict: {sms: {...}, whatsapp: {...}, both_success: bool}
    """
    sms_result = send_sms_notification(mobile_number, sms_msg, complaint_id)
    wa_result = send_whatsapp_notification(mobile_number, whatsapp_msg, complaint_id)
    
    return {
        'sms': sms_result,
        'whatsapp': wa_result,
        'both_success': sms_result['success'] and wa_result['success'],
        'at_least_one': sms_result['success'] or wa_result['success']
    }

# ============================================================================
# SEND ALL NOTIFICATION TYPES (WhatsApp + SMS fallback)
# ============================================================================

def send_all_notifications(mobile_number, message_data, complaint_id=None, 
                          use_sms=True, use_whatsapp=True, use_database=True):
    """
    Send notifications through all available channels
    
    Args:
        mobile_number: Citizen's mobile number
        message_data: {
            'short': 'SMS message (160 chars max)',
            'long': 'WhatsApp/DB message (can be longer)'
        }
        complaint_id: Complaint ID
        use_sms: Send SMS? (default: True)
        use_whatsapp: Send WhatsApp? (default: True)
        use_database: Save to database? (default: True)
    
    Returns:
        dict: {sms: {...}, whatsapp: {...}, database: {...}, summary: {...}}
    """
    results = {}
    
    # Send SMS
    if use_sms:
        results['sms'] = send_sms_notification(mobile_number, message_data.get('short', ''), complaint_id)
    
    # Send WhatsApp
    if use_whatsapp:
        results['whatsapp'] = send_whatsapp_notification(mobile_number, message_data.get('long', ''), complaint_id)
    
    # Save to database (if needed)
    if use_database:
        try:
            from notifications import create_citizen_notification
            db_result = create_citizen_notification(
                complaint_id=complaint_id,
                mobile_number=mobile_number,
                citizen_name='Citizen',
                notification_type='system',
                message=message_data.get('long', '')
            )
            results['database'] = {'success': db_result}
        except Exception as e:
            results['database'] = {'success': False, 'error': str(e)}
    
    # Summary
    sent_count = sum(1 for r in results.values() if isinstance(r, dict) and r.get('success'))
    results['summary'] = {
        'total_channels': len(results),
        'successfully_sent': sent_count,
        'status': 'success' if sent_count > 0 else 'failed'
    }
    
    return results

# ============================================================================
# TESTING FUNCTIONS
# ============================================================================

def test_sms_notification(mobile_number=None):
    """Test SMS sending"""
    if not mobile_number:
        mobile_number = input("Enter mobile number to test SMS (10 digits): ")
    
    print(f"\n📱 Testing SMS to {mobile_number}...")
    result = send_sms_complaint_registered(mobile_number, 123, 'Raj Kumar')
    print(f"Result: {result}\n")
    return result

def test_whatsapp_notification(mobile_number=None):
    """Test WhatsApp sending"""
    if not mobile_number:
        mobile_number = input("Enter mobile number to test WhatsApp (10 digits): ")
    
    print(f"\n💬 Testing WhatsApp to {mobile_number}...")
    result = send_whatsapp_complaint_registered(mobile_number, 123, 'Raj Kumar')
    print(f"Result: {result}\n")
    return result

def test_all_notifications(mobile_number=None):
    """Test all notification types"""
    if not mobile_number:
        mobile_number = input("Enter mobile number to test (10 digits): ")
    
    print(f"\n🔔 Testing ALL notifications to {mobile_number}...\n")
    
    message_data = {
        'short': 'आपली तक्रार #123 नोंदवली गेली',
        'long': 'नमस्कार! आपली तक्रार यशस्वीरित्या नोंदवली गेली. तक्रार क्रमांक: #123'
    }
    
    result = send_all_notifications(mobile_number, message_data, complaint_id=123)
    
    print("📊 Results:")
    for channel, res in result.items():
        if isinstance(res, dict):
            status = "✓" if res.get('success') else "✗"
            print(f"  {status} {channel.upper()}: {res.get('error', 'Success')}")
    
    return result

# ============================================================================
# CONFIGURATION HELPER
# ============================================================================

def setup_twilio_credentials(account_sid, auth_token, phone_number, whatsapp_number):
    """
    Setup Twilio credentials (call this during initialization)
    
    Example:
        setup_twilio_credentials(
            'ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx',
            'your_auth_token_here',
            '+1234567890',
            'whatsapp:+1234567890'
        )
    """
    global TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, TWILIO_PHONE_NUMBER, TWILIO_WHATSAPP_NUMBER, twilio_client
    
    TWILIO_ACCOUNT_SID = account_sid
    TWILIO_AUTH_TOKEN = auth_token
    TWILIO_PHONE_NUMBER = phone_number
    TWILIO_WHATSAPP_NUMBER = whatsapp_number
    
    if TWILIO_AVAILABLE:
        twilio_client = Client(account_sid, auth_token)
        print("✓ Twilio configured successfully!")
        return True
    else:
        print("✗ Twilio library not installed")
        return False

def get_twilio_status():
    """Check if Twilio is configured"""
    status = {
        'twilio_available': TWILIO_AVAILABLE,
        'configured': twilio_client is not None,
        'account_sid': TWILIO_ACCOUNT_SID[:10] + '...' if TWILIO_ACCOUNT_SID else 'Not set',
        'phone_number': TWILIO_PHONE_NUMBER,
        'whatsapp_number': TWILIO_WHATSAPP_NUMBER
    }
    return status
