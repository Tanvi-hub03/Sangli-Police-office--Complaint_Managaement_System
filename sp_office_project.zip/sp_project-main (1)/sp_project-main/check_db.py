#!/usr/bin/env python3
"""
Database Diagnostics Script
Checks database connectivity and schema
"""

import mysql.connector
from mysql.connector import Error

def check_mysql_connection():
    """Test basic MySQL connection"""
    print("=" * 50)
    print("1. Testing MySQL Connection...")
    print("=" * 50)
    
    try:
        connection = mysql.connector.connect(
            host="localhost",
            user="root",
            password="root",
            port=3407
        )
        
        if connection.is_connected():
            print("✓ MySQL Server is running and accessible")
            return connection
        else:
            print("✗ MySQL connection failed")
            return None
            
    except Error as e:
        print(f"✗ MySQL Connection Error: {e}")
        return None

def check_database_exists(connection):
    """Check if spdata database exists"""
    print("\n" + "=" * 50)
    print("2. Checking Database...")
    print("=" * 50)
    
    try:
        cursor = connection.cursor()
        cursor.execute("SHOW DATABASES LIKE 'spdata';")
        result = cursor.fetchone()
        
        if result:
            print("✓ Database 'spdata' exists")
            return True
        else:
            print("✗ Database 'spdata' NOT found")
            print("  → Creating database...")
            cursor.execute("CREATE DATABASE spdata;")
            connection.commit()
            print("✓ Database 'spdata' created")
            return True
            
    except Error as e:
        print(f"✗ Error: {e}")
        return False

def check_tables(connection):
    """Check if tables exist"""
    print("\n" + "=" * 50)
    print("3. Checking Tables...")
    print("=" * 50)
    
    try:
        cursor = connection.cursor()
        
        # Switch to spdata database
        cursor.execute("USE spdata;")
        
        # Check RegistrationInfo table
        cursor.execute("""
            SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES 
            WHERE TABLE_SCHEMA='spdata' AND TABLE_NAME='RegistrationInfo'
        """)
        
        if cursor.fetchone():
            print("✓ RegistrationInfo table exists")
        else:
            print("✗ RegistrationInfo table NOT found")
            return False
        
        # Check Complaints table
        cursor.execute("""
            SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES 
            WHERE TABLE_SCHEMA='spdata' AND TABLE_NAME='Complaints'
        """)
        
        if cursor.fetchone():
            print("✓ Complaints table exists")
        else:
            print("✗ Complaints table NOT found")
            return False
        
        return True
        
    except Error as e:
        print(f"✗ Error: {e}")
        return False

def check_columns(connection):
    """Check if new columns exist"""
    print("\n" + "=" * 50)
    print("4. Checking New Columns...")
    print("=" * 50)
    
    try:
        cursor = connection.cursor()
        cursor.execute("USE spdata;")
        
        # Check officer_role column
        cursor.execute("""
            SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS 
            WHERE TABLE_NAME='RegistrationInfo' AND COLUMN_NAME='officer_role'
        """)
        
        if cursor.fetchone():
            print("✓ officer_role column exists in RegistrationInfo")
        else:
            print("✗ officer_role column NOT found")
            print("  → Run: python migrate_db.py")
        
        # Check status column
        cursor.execute("""
            SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS 
            WHERE TABLE_NAME='Complaints' AND COLUMN_NAME='status'
        """)
        
        if cursor.fetchone():
            print("✓ status column exists in Complaints")
        else:
            print("✗ status column NOT found")
            print("  → Run: python migrate_db.py")
        
        return True
        
    except Error as e:
        print(f"✗ Error: {e}")
        return False

def main():
    print("\n" + "=" * 50)
    print("DATABASE DIAGNOSTICS")
    print("=" * 50 + "\n")
    
    # Test MySQL connection
    connection = check_mysql_connection()
    if not connection:
        print("\n❌ FATAL: Cannot connect to MySQL")
        print("   Make sure MySQL is running!")
        return
    
    # Check database
    if not check_database_exists(connection):
        print("\n❌ FATAL: Cannot access database")
        return
    
    # Check tables
    if not check_tables(connection):
        print("\n⚠️  Tables missing!")
        print("   Run: python migrate_db.py")
        connection.close()
        return
    
    # Check columns
    check_columns(connection)
    
    connection.close()
    
    print("\n" + "=" * 50)
    print("✓ ALL CHECKS PASSED!")
    print("=" * 50)
    print("\nYour system is ready to use!")
    print("Try logging in again at: http://localhost:5000")

if __name__ == '__main__':
    main()
