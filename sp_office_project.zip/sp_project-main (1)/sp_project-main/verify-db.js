// Database Connection Test Script
// Run this to verify MySQL connection: node verify-db.js

const mysql = require('mysql2/promise');

// Database configuration
const dbConfig = {
    host: 'localhost',
    user: 'root',
    password: 'root',
    database: 'SPDATA'
};

async function testConnection() {
    try {
        console.log('🔄 Testing MySQL connection...');
        console.log('📋 Configuration:', {
            host: dbConfig.host,
            user: dbConfig.user,
            database: dbConfig.database
        });
        
        // Create connection
        const connection = await mysql.createConnection(dbConfig);
        console.log('✅ Connected to MySQL successfully!');
        
        // Test database
        const [databases] = await connection.execute('SHOW DATABASES LIKE "SPDATA"');
        if (databases.length > 0) {
            console.log('✅ Database SPDATA found!');
        } else {
            console.log('❌ Database SPDATA not found. Please run setup.sql');
            await connection.end();
            return;
        }
        
        // Test table
        const [tables] = await connection.execute(
            'SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = "SPDATA" AND TABLE_NAME = "RegistrationIfo"'
        );
        
        if (tables.length > 0) {
            console.log('✅ Table RegistrationIfo found!');
        } else {
            console.log('❌ Table RegistrationIfo not found. Please run setup.sql');
            await connection.end();
            return;
        }
        
        // Test table structure
        const [columns] = await connection.execute('DESCRIBE RegistrationIfo');
        console.log('\n📊 Table Structure:');
        console.table(columns);
        
        // Count records
        const [records] = await connection.execute('SELECT COUNT(*) as count FROM RegistrationIfo');
        console.log('\n📈 Total Records:', records[0].count);
        
        // Show sample data if exists
        if (records[0].count > 0) {
            const [data] = await connection.execute('SELECT * FROM RegistrationIfo LIMIT 5');
            console.log('\n📋 Sample Data:');
            console.table(data);
        }
        
        // Close connection
        await connection.end();
        
        console.log('\n✅ All checks passed! Database is ready for registration.');
        
    } catch (error) {
        console.error('\n❌ Error:', error.message);
        console.error('\n📌 Troubleshooting:');
        console.error('1. Ensure MySQL server is running');
        console.error('2. Check database credentials in db-config.js');
        console.error('3. Run setup.sql to create database and table');
        console.error('4. Check MySQL port (default: 3306)');
        process.exit(1);
    }
}

// Run test
testConnection();
