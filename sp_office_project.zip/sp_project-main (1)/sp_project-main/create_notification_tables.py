#!/usr/bin/env python3
"""
Create Notifications and Reminders Tables
"""

import mysql.connector
from mysql.connector import Error

def get_db_connection():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        port=3407
    )

def create_notification_tables():
    """Create Notifications and Reminders tables"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        # Use database
        cursor.execute("USE spdata;")
        print("✓ Using database: spdata")
        
        # Create Notifications table (for Citizens)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS Notifications (
                notification_id INT PRIMARY KEY AUTO_INCREMENT,
                complaint_id INT NOT NULL,
                mobile_number VARCHAR(10) NOT NULL,
                citizen_name VARCHAR(100) NOT NULL,
                notification_type VARCHAR(50),
                message TEXT NOT NULL,
                is_read BOOLEAN DEFAULT FALSE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (complaint_id) REFERENCES Complaints(complaint_id),
                INDEX idx_mobile (mobile_number),
                INDEX idx_complaint (complaint_id),
                INDEX idx_is_read (is_read)
            )
        """)
        print("✓ Created Notifications table (for Citizens)")
        
        # Create Reminders table (for Officers)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS Reminders (
                reminder_id INT PRIMARY KEY AUTO_INCREMENT,
                complaint_id INT NOT NULL,
                officer_id INT NOT NULL,
                priority VARCHAR(50) NOT NULL,
                pending_days INT,
                due_date DATETIME,
                reminder_message TEXT NOT NULL,
                is_acknowledged BOOLEAN DEFAULT FALSE,
                is_resolved BOOLEAN DEFAULT FALSE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                FOREIGN KEY (complaint_id) REFERENCES Complaints(complaint_id),
                FOREIGN KEY (officer_id) REFERENCES RegistrationInfo(Sr_No),
                INDEX idx_officer (officer_id),
                INDEX idx_complaint (complaint_id),
                INDEX idx_priority (priority),
                INDEX idx_is_acknowledged (is_acknowledged)
            )
        """)
        print("✓ Created Reminders table (for Officers)")
        
        conn.commit()
        print("\n✓ ALL NOTIFICATION TABLES CREATED SUCCESSFULLY!")
        
    except Error as e:
        print(f"✗ Error: {e}")
    finally:
        cursor.close()
        conn.close()

if __name__ == '__main__':
    print("=" * 50)
    print("Creating Notification Tables")
    print("=" * 50 + "\n")
    create_notification_tables()
