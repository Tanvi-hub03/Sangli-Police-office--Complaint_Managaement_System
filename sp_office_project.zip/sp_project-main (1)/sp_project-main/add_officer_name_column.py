#!/usr/bin/env python3
import mysql.connector
from mysql.connector import Error

def get_db_connection():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database="spdata",
        port=3407
    )

def add_officer_name_column():
    """Add officerName column to Complaints table"""
    connection = None
    cursor = None
    try:
        connection = get_db_connection()
        cursor = connection.cursor()
        
        print("Checking if officerName column exists...")
        
        # Check if officerName column exists
        cursor.execute("""
            SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS 
            WHERE TABLE_NAME='Complaints' AND COLUMN_NAME='officerName'
        """)
        
        if cursor.fetchone():
            print("✓ officerName column already exists")
        else:
            print("✗ officerName column not found. Adding it...")
            cursor.execute("""
                ALTER TABLE Complaints 
                ADD COLUMN officerName VARCHAR(100)
            """)
            connection.commit()
            print("✓ officerName column added successfully")
        
        # Show table structure
        cursor.execute("""
            SELECT COLUMN_NAME, COLUMN_TYPE 
            FROM INFORMATION_SCHEMA.COLUMNS 
            WHERE TABLE_NAME='Complaints'
            ORDER BY ORDINAL_POSITION
        """)
        
        columns = cursor.fetchall()
        print("\n" + "="*60)
        print("Complaints Table Structure:")
        print("="*60)
        for col in columns:
            print(f"  {col[0]}: {col[1]}")
        
        print("="*60)
        print("✓ Database schema updated successfully!")
        
    except Error as e:
        print(f"✗ Database error: {e}")
    finally:
        if cursor:
            cursor.close()
        if connection and connection.is_connected():
            connection.close()

if __name__ == "__main__":
    add_officer_name_column()
