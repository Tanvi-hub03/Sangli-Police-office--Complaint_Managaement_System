# 🎯 Notification & Reminder System - Complete Guide

## ✅ System Overview

```
┌─────────────────────────────────────────────────────┐
│                  COMPLAINT SYSTEM                   │
├─────────────────────────────────────────────────────┤
│                                                     │
│  👤 CITIZEN                 👮 OFFICER  👨‍💼 ADMIN   │
│  ├─ Status Check            ├─ Dashboard           │
│  │  (Mobile #)              │  ├─ All Reminders   │
│  │                          │  ├─ Overdue         │
│  └─ Notifications           │  ├─ High Priority   │
│     (Auto Updates)          │  └─ Stats           │
│                             │                     │
│                             └─ Can Acknowledge    │
│                                & Resolve          │
│                                                     │
└─────────────────────────────────────────────────────┘

NOTIFICATION TYPES:
- Citizen → Status Updates (registered, updated, resolved)
- Officer → Priority-based Reminders (after login)
```

---

## 📊 Database Tables Created

### 1. **Notifications Table** (Citizens)
```sql
Notifications
├─ notification_id (PK)
├─ complaint_id (FK → Complaints)
├─ mobile_number
├─ citizen_name
├─ notification_type (registered/updated/resolved)
├─ message
├─ is_read (boolean)
└─ created_at (timestamp)
```

### 2. **Reminders Table** (Officers)
```sql
Reminders
├─ reminder_id (PK)
├─ complaint_id (FK → Complaints)
├─ officer_id (FK → RegistrationInfo)
├─ priority (High/Medium/Normal)
├─ pending_days
├─ due_date
├─ reminder_message
├─ is_acknowledged (boolean)
├─ is_resolved (boolean)
├─ created_at & updated_at
└─ INDEX: officer_id, complaint_id, priority
```

---

## 🚀 Setup Instructions

### Step 1: Create Database Tables

Run this Python script to create the notification tables:

```bash
python create_notification_tables.py
```

Expected output:
```
✓ Using database: spdata
✓ Created Notifications table (for Citizens)
✓ Created Reminders table (for Officers)
✓ ALL NOTIFICATION TABLES CREATED SUCCESSFULLY!
```

### Step 2: Verify Files Created

The following new files should be in your project:

```
✅ create_notification_tables.py    → Creates DB tables
✅ notifications.py                 → Backend logic (Python)
✅ OfficerDashboard.html           → Officer UI (Reminders)
✅ CitizenStatusCheck.html         → Citizen UI (Status lookup)
✅ NOTIFICATION_SYSTEM_GUIDE.md    → This file
```

### Step 3: Restart Flask Server

The `app.py` has been updated with new API routes:

```bash
python app.py
```

Your server will now have these new endpoints:
- `/api/citizen-notifications/<mobile>`
- `/api/check-complaint-status/<mobile>`
- `/api/officer-reminders/<officer_id>`
- `/api/acknowledge-reminder/<reminder_id>`
- `/api/resolve-reminder/<reminder_id>`

---

## 🎯 Usage Flows

### 👤 CITIZEN FLOW

#### 1. Check Complaint Status
- Visit: **http://localhost:5000/CitizenStatusCheck.html**
- Enter 10-digit mobile number
- View all complaints and notifications

#### 2. What Citizens See
```
✓ Complaint ID & Details
✓ Current Status (Pending/Updated/Resolved)
✓ Assigned Officer Name
✓ Priority Level
✓ All notifications/updates about their complaints
```

#### 3. Notifications Sent to Citizens
- **On Registration:** "Your complaint has been registered successfully (ID: #123)"
- **On Update:** "Your complaint status has been updated. Check dashboard for details."
- **On Resolution:** "Your complaint has been resolved. Thank you!"

---

### 👮 OFFICER FLOW

#### 1. View Officer Dashboard
- Visit: **http://localhost:5000/OfficerDashboard.html?officer_id=1**
- (or embed officer_id from login)

#### 2. Dashboard Shows
```
📊 STATISTICS
├─ Total Active Reminders
├─ Overdue Reminders
└─ High Priority Count

🔔 REMINDER LIST
├─ Filter: All / Overdue / High Priority / Pending
├─ Sort by: Priority → Due Date
└─ Actions: Acknowledge / Resolve

⏰ COLOR CODING
├─ 🔴 HIGH PRIORITY (24-hour deadline)
├─ 🟠 MEDIUM (48-hour deadline)
└─ 🟦 NORMAL (1-week deadline)
```

#### 3. Officer Actions
1. **Acknowledge** - Mark reminder as seen
2. **Resolve** - Mark complaint as resolved (hides from list)

#### 4. Auto-Refresh
- Dashboard refreshes every 30 seconds
- Real-time reminder updates

---

## 💻 Backend API Reference

### 1. **Citizen Notifications**

```
GET /api/citizen-notifications/<mobile_number>

Response:
{
  "success": true,
  "count": 2,
  "notifications": [
    {
      "notification_id": 1,
      "complaint_id": 101,
      "mobile_number": "9876543210",
      "notification_type": "registered",
      "message": "Your complaint has been registered...",
      "is_read": false,
      "created_at": "2026-01-23 10:30:00"
    }
  ]
}
```

---

### 2. **Check Complaint Status**

```
GET /api/check-complaint-status/<mobile_number>

Response:
{
  "success": true,
  "total_complaints": 2,
  "complaints": [
    {
      "complaint_id": 101,
      "reason": "Water supply issue",
      "status": "Pending",
      "priority": "High",
      "submittedAt": "2026-01-20",
      "officerName": "Raj Kumar"
    }
  ],
  "notifications": [...]
}
```

---

### 3. **Officer Reminders**

```
GET /api/officer-reminders/<officer_id>

Response:
{
  "success": true,
  "total_reminders": 3,
  "overdue_count": 1,
  "statistics": {
    "total_active": 3,
    "overdue": 1,
    "high_priority": 2
  },
  "reminders": [
    {
      "reminder_id": 1,
      "complaint_id": 101,
      "priority": "High",
      "due_date": "2026-01-24 10:00:00",
      "pending_days": -1,
      "reminder_message": "Complaint ID #101...",
      "is_acknowledged": false,
      "name": "Raj Kumar"
    }
  ]
}
```

---

### 4. **Acknowledge Reminder**

```
POST /api/acknowledge-reminder/<reminder_id>

Response:
{
  "success": true,
  "message": "Reminder acknowledged"
}
```

---

### 5. **Resolve Reminder**

```
POST /api/resolve-reminder/<reminder_id>

Response:
{
  "success": true,
  "message": "Reminder resolved"
}
```

---

## 🔄 Auto-Generate Reminders Logic

When a complaint is created/updated, reminders are automatically generated:

```python
from notifications import generate_reminders_for_complaint

# Call this after complaint creation/update
generate_reminders_for_complaint(complaint_id)
```

**Time Limits by Priority:**
```
Priority    Time Limit    Trigger
─────────────────────────────────
High        24 hours      Immediate + before deadline
Medium      48 hours      If nearing deadline
Normal      1 week        If nearing deadline
```

---

## 📱 Integration Points

### When Complaint is Created:
1. Auto-generate reminders for all officers
2. Send notification to citizen: "Complaint registered"

### When Complaint Status Updated:
1. Update reminders (if priority changed)
2. Send notification to citizen: "Status updated"

### When Complaint Resolved:
1. Resolve all related reminders
2. Send notification to citizen: "Complaint resolved"

---

## 🛠️ Customization Guide

### Change Notification Message

In `notifications.py`:
```python
def create_citizen_notification(...):
    message = "Your custom message here"
    create_citizen_notification(
        complaint_id=123,
        message=message  # Customize this
    )
```

### Change Priority Time Limits

In `notifications.py`, function `generate_reminders_for_complaint()`:
```python
time_limits = {
    'High': 24,      # Change from 24 to any hours
    'Medium': 48,    # Change as needed
    'Normal': 168    # 1 week = 168 hours
}
```

### Change Dashboard Colors

In `OfficerDashboard.html`, CSS section:
```css
.reminder-card.high-priority {
    border-left: 6px solid #ff6b6b;  /* Change color */
}
```

---

## ✅ Testing Checklist

- [ ] Notification tables created successfully
- [ ] Flask server running without errors
- [ ] Officer Dashboard loads and shows reminders
- [ ] Citizen Status Check page works
- [ ] Can search by mobile number (10 digits)
- [ ] Acknowledge button works
- [ ] Resolve button works
- [ ] Dashboard auto-refreshes
- [ ] Correct priority colors showing
- [ ] Overdue badges appear correctly

---

## 🐛 Troubleshooting

### Issue: "Database connection failed"
**Solution:** Verify MySQL is running and credentials in `DB_CONFIG` are correct

```bash
# Check MySQL status
mysql -h localhost -u root -p -e "SELECT 1;"
```

### Issue: "Notification table not found"
**Solution:** Run the creation script

```bash
python create_notification_tables.py
```

### Issue: Officer Dashboard shows no reminders
**Solution:** Ensure:
1. Officer ID is passed correctly in URL
2. Complaints exist for that officer
3. `generate_reminders_for_complaint()` was called after complaint creation

### Issue: Citizen search returns nothing
**Solution:** Verify:
1. Mobile number is exactly 10 digits
2. Complaint exists with that mobile number
3. Check database: `SELECT * FROM Complaints WHERE mobile = '9876543210';`

---

## 📊 Database Queries Reference

### Get all active reminders for officer
```sql
SELECT * FROM Reminders 
WHERE officer_id = 1 AND is_resolved = FALSE
ORDER BY priority DESC, due_date ASC;
```

### Get overdue reminders
```sql
SELECT * FROM Reminders 
WHERE officer_id = 1 AND is_resolved = FALSE AND due_date < NOW();
```

### Get all notifications for citizen
```sql
SELECT * FROM Notifications 
WHERE mobile_number = '9876543210' 
ORDER BY created_at DESC;
```

### Get complaint stats
```sql
SELECT 
  status, 
  COUNT(*) as count 
FROM Complaints 
WHERE mobile = '9876543210' 
GROUP BY status;
```

---

## 🎉 Next Steps

1. ✅ Create tables (`python create_notification_tables.py`)
2. ✅ Restart Flask server
3. ✅ Test Officer Dashboard
4. ✅ Test Citizen Status Check
5. ✅ Verify reminders auto-generate
6. 📊 Monitor reminders in production
7. 📈 Add more features as needed

---

## 📞 Support

For issues or customizations needed:
- Check this guide first
- Review database queries
- Check browser console for JavaScript errors
- Check server logs for Python errors

**Happy complaint management! 🚀**
