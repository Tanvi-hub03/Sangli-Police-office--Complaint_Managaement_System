#!/usr/bin/env python
# -*- coding: utf-8 -*-
import mysql.connector
from mysql.connector import Error

DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': 'root',
    'database': 'spdata',
    'port': 3407
}

try:
    connection = mysql.connector.connect(**DB_CONFIG)
    cursor = connection.cursor(dictionary=True)
    
    # Check total complaints
    cursor.execute("SELECT COUNT(*) as total FROM Complaints")
    result = cursor.fetchone()
    print(f"Total Complaints: {result['total']}")
    
    # Check complaints with officer names
    cursor.execute("SELECT COUNT(*) as total FROM Complaints WHERE officerName IS NOT NULL AND officerName != ''")
    result = cursor.fetchone()
    print(f"Complaints with Officer: {result['total']}")
    
    # Check sample complaints
    print("\n=== Sample Complaints ===")
    cursor.execute("""
        SELECT complaint_id, inwardNo, name, officerName as officer_name, status 
        FROM Complaints 
        LIMIT 5
    """)
    complaints = cursor.fetchall()
    for c in complaints:
        print(c)
    
    cursor.close()
    connection.close()
    
except Error as e:
    print(f"Error: {e}")
