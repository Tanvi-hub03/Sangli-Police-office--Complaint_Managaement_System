-- SQL Script to create SPDATA database and RegistrationIfo table
-- Run this in phpMyAdmin, MySQL Workbench, or MySQL command line

-- Create the database
CREATE DATABASE IF NOT EXISTS SPDATA;

-- Use the database
USE SPDATA;

-- Create the RegistrationIfo table
CREATE TABLE IF NOT EXISTS RegistrationIfo (
    Sr_No INT AUTO_INCREMENT PRIMARY KEY COMMENT 'Serial Number - Auto increment',
    Name_of_Registerer VARCHAR(20) NOT NULL COMMENT 'Full name of registerer',
    Address VARCHAR(100) NOT NULL COMMENT 'Address of registerer',
    Date_of_birth DATE NOT NULL COMMENT 'Date of birth (YYYY-MM-DD format)',
    Mobile_Number VARCHAR(10) NOT NULL UNIQUE COMMENT '10-digit mobile number',
    Email VARCHAR(100) COMMENT 'Email address',
    user_name VARCHAR(20) NOT NULL UNIQUE COMMENT 'Unique username for login',
    Password VARCHAR(50) NOT NULL COMMENT 'Password for login',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT 'Record creation timestamp'
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = 'Registration information table for Sangli Police VMS';

-- Show table structure
DESCRIBE RegistrationIfo;

-- Show all records (will be empty initially)
SELECT * FROM RegistrationIfo;

-- Add INDEX for faster lookups (optional but recommended)
ALTER TABLE RegistrationIfo
ADD INDEX idx_username (user_name),
ADD INDEX idx_mobile (Mobile_Number),
ADD INDEX idx_created (created_at);

-- Display success message
SELECT 'Database SPDATA and table RegistrationIfo created successfully!' as Status;
