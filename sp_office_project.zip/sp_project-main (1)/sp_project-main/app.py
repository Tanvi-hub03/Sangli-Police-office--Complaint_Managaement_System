# Flask Server for Login & Registration System
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import mysql.connector
from mysql.connector import Error
import os
from notifications import (
    create_citizen_notification, get_citizen_notifications, mark_notification_as_read,
    create_officer_reminder, get_officer_reminders, get_overdue_reminders, 
    acknowledge_reminder, resolve_reminder, generate_reminders_for_complaint,
    get_reminder_statistics, create_officer_notification, get_officer_notifications,
    mark_officer_notification_read, check_and_generate_recurring_reminders
)

app = Flask(__name__, static_folder='.')
CORS(app)  # Enable CORS for all routes

# Database Configuration
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': 'root',
    'database': 'spdata',
    'port': 3407
}


# Admin Configuration
ADMIN_USERNAME = 'admin'
ADMIN_PASSWORD = 'admin@1234'

def migrate_db():
    """Add new columns if they don't exist"""
    connection = get_db_connection()
    if not connection:
        print("Migration failed: Could not connect to DB")
        return
    
    cursor = connection.cursor()
    try:
        print("Checking database schema...")
        cursor.execute("DESCRIBE Complaints")
        columns = [row[0] for row in cursor.fetchall()]
        
        if 'fromDept' not in columns:
            print("Adding fromDept column...")
            cursor.execute("ALTER TABLE Complaints ADD COLUMN fromDept VARCHAR(255)")
        
        if 'toDept' not in columns:
            print("Adding toDept column...")
            cursor.execute("ALTER TABLE Complaints ADD COLUMN toDept VARCHAR(255)")
            
        connection.commit()
        print("Schema migration completed.")
    except Exception as e:
        print(f"Migration error: {e}")
    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()

def get_db_connection():
    """Create and return database connection"""
    try:
        connection = mysql.connector.connect(**DB_CONFIG)
        if connection.is_connected():
            return connection
    except Error as e:
        print(f"Error connecting to MySQL: {e}")
        return None

# Serve static files (HTML, CSS, JS)
@app.route('/')
def index():
    from flask import redirect
    return redirect('/Login.html')

@app.route('/favicon.ico')
def favicon():
    """Serve favicon"""
    try:
        return send_from_directory('assets', 'favicon.svg')
    except:
        return '', 204

@app.route('/assets/<path:filename>')
def serve_assets(filename):
    """Serve asset files from assets folder"""
    return send_from_directory('assets', filename)

@app.route('/<path:filename>')
def serve_static(filename):
    """Serve static files"""
    return send_from_directory('.', filename)

# Registration API Endpoint
@app.route('/api/register', methods=['POST'])
def register():
    connection = None
    cursor = None
    try:
        # Get JSON data from request
        data = request.get_json()
        
        # Extract and validate input data
        full_name = data.get('fullName', '').strip()
        address = data.get('address', '').strip()
        date_of_birth = data.get('dateOfBirth', '').strip()
        mobile_number = data.get('mobileNumber', '').strip()
        email = data.get('email', '').strip()
        username = data.get('username', '').strip()
        password = data.get('password', '').strip()
        district = data.get('district', '').strip()
        
        # Validate required fields
        if not all([full_name, address, date_of_birth, mobile_number, email, username, password, district]):
            return jsonify({
                'success': False,
                'message': 'All fields are required'
            }), 400
        
        # Validate mobile number format (10 digits)
        if not mobile_number.isdigit() or len(mobile_number) != 10:
            return jsonify({
                'success': False,
                'message': 'Invalid mobile number format. Please enter 10 digits.'
            }), 400
        
        # Validate email format
        import re
        if not re.match(r'^[^\s@]+@[^\s@]+\.[^\s@]+$', email):
            return jsonify({
                'success': False,
                'message': 'Invalid email format. Please enter a valid email address.'
            }), 400
        
        # Validate username format
        if not re.match(r'^[a-zA-Z0-9_]{3,20}$', username):
            return jsonify({
                'success': False,
                'message': 'Invalid username format. Username must be 3-20 characters (letters, numbers, underscore only).'
            }), 400
        
        # Connect to database
        connection = get_db_connection()
        if not connection:
            return jsonify({
                'success': False,
                'message': 'Database connection failed. Please try again later.'
            }), 500
        
        cursor = connection.cursor()
        
        # Check if username already exists
        cursor.execute("SELECT user_name FROM RegistrationInfo WHERE user_name = %s", (username,))
        if cursor.fetchone():
            return jsonify({
                'success': False,
                'message': 'Username already exists. Please choose a different username.'
            }), 400
        
        # Check if mobile number already exists
        cursor.execute("SELECT Mobile_Number FROM RegistrationInfo WHERE Mobile_Number = %s", (mobile_number,))
        if cursor.fetchone():
            return jsonify({
                'success': False,
                'message': 'Mobile number already registered. Please use a different mobile number.'
            }), 400
        
        # Check if email already exists (only if email is provided)
        if email:
            cursor.execute("SELECT Email FROM RegistrationInfo WHERE Email = %s", (email,))
            if cursor.fetchone():
                return jsonify({
                    'success': False,
                    'message': 'Email already registered. Please use a different email address.'
                }), 400
        
        # Get the next Sr_No (serial number) - handle NULL case
        cursor.execute("SELECT COALESCE(MAX(Sr_No), 0) as max_sr FROM RegistrationInfo")
        result = cursor.fetchone()
        next_sr_no = result[0] + 1 if result and result[0] else 1
        
        print(f"Next Sr_No to insert: {next_sr_no}")
        
        # Insert new registration (Officer Registration)
        insert_query = """
            INSERT INTO RegistrationInfo 
            (Sr_No, Name_of_Registerer, Address, Date_of_birth, Mobile_Number, Email, user_name, Password, officer_role, district) 
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """
        cursor.execute(insert_query, (
            next_sr_no, full_name, address, date_of_birth, 
            mobile_number, email, username, password, 'officer', district
        ))
        
        connection.commit()
        print(f"Registration successful! New Sr_No: {next_sr_no}")
        
        return jsonify({
            'success': True,
            'message': f'Registration successful! Welcome, {full_name}!',
            'sr_no': next_sr_no
        }), 200
        
    except Error as e:
        print(f"Database error: {e}")
        return jsonify({
            'success': False,
            'message': 'An error occurred during registration. Please try again later.'
        }), 500
    except Exception as e:
        print(f"Error: {e}")
        return jsonify({
            'success': False,
            'message': 'An error occurred. Please try again.'
        }), 500
    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()

# Login API Endpoint
@app.route('/api/login', methods=['POST'])
def login():
    """Handle user login with username and password"""
    connection = None
    cursor = None
    try:
        # Get JSON data from request
        data = request.get_json()
        print(f"Login request data: {data}")  # Debug log
        
        # Extract input data
        username = data.get('username', '').strip() if data else ''
        password = data.get('password', '').strip() if data else ''
        
        print(f"Username: '{username}', Password: '{password}'")  # Debug log
        
        # Validate required fields
        if not username or not password:
            return jsonify({
                'success': False,
                'message': 'वापरकर्तानाव आणि पासवर्ड आवश्यक आहे'
            }), 400
        
        # Connect to database
        connection = get_db_connection()
        if not connection:
            return jsonify({
                'success': False,
                'message': 'डेटाबेस कनेक्शन अयशस्वी. कृपया पुन्हा प्रयत्न करा.'
            }), 500
        
        cursor = connection.cursor(dictionary=True, buffered=True)
        
        # Check if username and password match in RegistrationInfo table
        cursor.execute("""
            SELECT Sr_No, Name_of_Registerer, Email, user_name, Mobile_Number, officer_role, district
            FROM RegistrationInfo 
            WHERE user_name = %s AND Password = %s
        """, (username, password))
        
        user = cursor.fetchone()
        cursor.fetchall()  # Consume all remaining results
        
        if user:
            # Check if user is an officer
            if user['officer_role'] != 'officer':
                return jsonify({
                    'success': False,
                    'message': 'केवळ अधिकारी लॉगिन करू शकतात!'
                }), 401
            
            return jsonify({
                'success': True,
                'message': 'यशस्वीरित्या लॉगिन झाले!',
                'user': {
                    'sr_no': user['Sr_No'],
                    'name': user['Name_of_Registerer'],
                    'username': user['user_name'],
                    'email': user['Email'],
                    'mobile': user['Mobile_Number'],
                    'district': user['district']
                },
                'redirect': 'CaseFile.html'
            }), 200
        else:
            return jsonify({
                'success': False,
                'message': 'वापरकर्तानाव किंवा पासवर्ड चुकीचा आहे!'
            }), 401
        
    except Error as e:
        print(f"Database error: {e}")
        return jsonify({
            'success': False,
            'message': 'डेटाबेस त्रुटी. कृपया पुन्हा प्रयत्न करा.'
        }), 500
    except Exception as e:
        print(f"Error: {e}")
        return jsonify({
            'success': False,
            'message': 'त्रुटी आली. कृपया पुन्हा प्रयत्न करा.'
        }), 500
    finally:
        if cursor:
            try:
                cursor.close()
            except:
                pass
        if connection:
            try:
                connection.close()
            except:
                pass

# Admin Login API Endpoint
@app.route('/api/admin-login', methods=['POST'])
def admin_login():
    """Handle admin login with hardcoded credentials"""
    try:
        # Get JSON data from request
        data = request.get_json()
        
        # Extract input data
        username = data.get('username', '').strip() if data else ''
        password = data.get('password', '').strip() if data else ''
        
        # Validate required fields
        if not username or not password:
            return jsonify({
                'success': False,
                'message': 'वापरकर्तानाव आणि पासवर्ड आवश्यक आहे'
            }), 400
        
        # Verify admin credentials
        if username == ADMIN_USERNAME and password == ADMIN_PASSWORD:
            return jsonify({
                'success': True,
                'message': 'व्यवस्थापक यशस्वीरित्या लॉगिन झाले!',
                'admin': {
                    'username': ADMIN_USERNAME,
                    'role': 'admin'
                }
            }), 200
        else:
            return jsonify({
                'success': False,
                'message': 'व्यवस्थापक वापरकर्तानाव किंवा पासवर्ड चुकीचा आहे!'
            }), 401
        
    except Exception as e:
        print(f"Error: {e}")
        return jsonify({
            'success': False,
            'message': 'त्रुटी आली. कृपया पुन्हा प्रयत्न करा.'
        }), 500

# Get All Complaints API Endpoint (for officers and admin)
@app.route('/api/get-all-complaints', methods=['GET'])
def get_all_complaints():
    """Get all complaints - returns all if admin, filters by district if officer"""
    connection = None
    cursor = None
    try:
        connection = get_db_connection()
        if not connection:
            return jsonify({'success': False, 'message': 'डेटाबेस जोडण्यात त्रुटी'}), 500
        
        cursor = connection.cursor(dictionary=True)
        
        # Get officer's district from query parameter (optional for admin)
        officer_district = request.args.get('district', '').strip()
        
        # If district is provided, filter by it (officer view)
        # If not provided, return all complaints (admin view)
        if officer_district:
            select_query = """
                SELECT c.complaint_id, c.sr_no, c.inwardNo, c.name, c.mobile, c.reason, c.date, 
                       c.district, c.priority, c.deptSent, c.submittedAt, c.userName, c.status,
                       c.officerName as officer_name, c.officerName as officer_mobile, c.fromDept, c.toDept
                FROM Complaints c
                WHERE c.district = %s
                ORDER BY c.submittedAt DESC
            """
            cursor.execute(select_query, (officer_district,))
        else:
            # Admin view - get all complaints
            select_query = """
                SELECT c.complaint_id, c.sr_no, c.inwardNo, c.name, c.mobile, c.reason, c.date, 
                       c.district, c.priority, c.deptSent, c.submittedAt, c.userName, c.status,
                       c.officerName as officer_name, c.officerName as officer_mobile, c.fromDept, c.toDept
                FROM Complaints c
                ORDER BY c.submittedAt DESC
            """
            cursor.execute(select_query)
        
        complaints = cursor.fetchall()
        
        # Format datetime for display
        formatted_complaints = []
        for complaint in complaints:
            complaint['submittedAt'] = complaint['submittedAt'].strftime('%d-%m-%Y %H:%M:%S') if complaint['submittedAt'] else ''
            formatted_complaints.append(complaint)
        
        return jsonify({
            'success': True,
            'complaints': formatted_complaints,
            'count': len(formatted_complaints)
        }), 200
        
    except Error as e:
        print(f"Database error: {e}")
        return jsonify({'success': False, 'message': f'डेटाबेस त्रुटी: {str(e)}'}), 500
    finally:
        if cursor:
            cursor.close()
            connection.close()

# My Complaints API Endpoint (Officer Specific)
@app.route('/api/my-complaints', methods=['GET'])
def get_my_complaints():
    """Get complaints assigned to the logged-in officer"""
    connection = None
    cursor = None
    try:
        connection = get_db_connection()
        if not connection:
            return jsonify({'success': False, 'message': 'Database connection error'}), 500
        
        cursor = connection.cursor(dictionary=True)
        
        # We identify officer by username or officerName sent from frontend (stored in localStorage)
        username = request.args.get('username', '').strip()
        officer_name = request.args.get('officerName', '').strip() # Fallback
        
        if not username:
             return jsonify({'success': False, 'message': 'Username required'}), 400
             
        # Secure query: Get complaints where officerName matches (Assigned)
        # We prioritize officerName (Full Name) because the UI displays Assigned Officer.
        # If user also wants to see created complaints, we can include userName check, 
        # but user specifically asked to "not show all" (implied unwanted created-for-others).
        
        # If officer_name is provided, use it. Else fall back to username (though likely won't match officerName column).
        
        if officer_name:
             select_query = """
                SELECT c.complaint_id, c.sr_no, c.inwardNo, c.name, c.mobile, c.reason, c.date, 
                       c.district, c.priority, c.deptSent, c.submittedAt, c.userName, c.status,
                       c.officerName as officer_name, c.fromDept, c.toDept
                FROM Complaints c
                WHERE c.officerName = %s
                ORDER BY c.submittedAt DESC
            """
             cursor.execute(select_query, (officer_name,))
             complaints = cursor.fetchall()
        else:
             # Strict Mode: If no officerName provided, we cannot filter by "assigned".
             # Returning empty list or error.
             # This prevents showing complaints created by user but assigned to others.
             print("Warning: get_my_complaints called without officerName. Returning empty.")
             complaints = []
        
        # Format datetime
        formatted_complaints = []
        for complaint in complaints:
            complaint['submittedAt'] = complaint['submittedAt'].strftime('%d-%m-%Y %H:%M:%S') if complaint['submittedAt'] else ''
            formatted_complaints.append(complaint)
        
        # Calculate stats
        total = len(complaints)
        pending = sum(1 for c in complaints if c['status'] == 'Pending')
        solved = sum(1 for c in complaints if c['status'] == 'Solved') # or 'Resolved'
        
        return jsonify({
            'success': True,
            'complaints': formatted_complaints,
            'stats': {
                'total': total,
                'pending': pending,
                'solved': solved
            }
        }), 200
        
    except Error as e:
        print(f"Database error: {e}")
        return jsonify({'success': False, 'message': f'Database error: {str(e)}'}), 500
    finally:
        if cursor:
            cursor.close()
        if connection and connection.is_connected():
            connection.close()

# View all registrations endpoint
@app.route('/api/view-registrations', methods=['GET'])
def view_registrations():
    """Get all registrations from database"""
    try:
        connection = get_db_connection()
        if not connection:
            return jsonify({
                'success': False,
                'message': 'Database connection failed.'
            }), 500
        
        cursor = connection.cursor(dictionary=True)
        cursor.execute("""
            SELECT Sr_No, Name_of_Registerer, Address, Date_of_birth, 
                   Mobile_Number, Email, user_name 
            FROM RegistrationInfo 
            ORDER BY Sr_No DESC
        """)
        
        registrations = cursor.fetchall()
        cursor.close()
        connection.close()
        
        return jsonify({
            'success': True,
            'registrations': registrations,
            'count': len(registrations)
        }), 200
        
    except Error as e:
        print(f"Database error: {e}")
        return jsonify({
            'success': False,
            'message': f'Database error: {str(e)}'
        }), 500
    except Exception as e:
        print(f"Error: {e}")
        return jsonify({
            'success': False,
            'message': f'An error occurred: {str(e)}'
        }), 500

# Health check endpoint
@app.route('/api/health', methods=['GET'])
def health_check():
    """Check database connection"""
    connection = get_db_connection()
    if connection:
        connection.close()
        return jsonify({'status': 'ok', 'database': 'connected'}), 200
    else:
        return jsonify({'status': 'error', 'database': 'disconnected'}), 500

# Save Complaint API Endpoint
@app.route('/api/save-complaint', methods=['POST'])
def save_complaint():
    connection = None
    cursor = None
    try:
        data = request.get_json()
        
        # Extract complaint data
        sr_no = data.get('sr_no')
        inwardNo = data.get('inwardNo', '').strip()
        name = data.get('name', '').strip()
        mobile = data.get('mobile', '').strip()
        address = data.get('address', '').strip()
        reason = data.get('reason', '').strip()
        date = data.get('date', '').strip()
        district = data.get('district', '').strip()
        deptSent = data.get('deptSent', '').strip()
        priority = data.get('priority', '').strip()
        userName = data.get('userName', '').strip()
        officerName = data.get('officerName', '').strip()
        
        # New Fields
        fromDept = data.get('fromDept', '').strip()
        toDept = data.get('toDept', '').strip()
        
        # Validate required fields
        if not sr_no or not inwardNo or not name or not mobile:
            return jsonify({'success': False, 'message': 'आवश्यक फील्ड भरा'}), 400
        
        # Validate mobile number
        if not mobile.isdigit() or len(mobile) != 10:
            return jsonify({'success': False, 'message': 'वैध १० अंकी मोबाईल क्रमांक प्रविष्ट करा'}), 400
        
        connection = get_db_connection()
        if not connection:
            return jsonify({'success': False, 'message': 'डेटाबेस जोडण्यात त्रुटी'}), 500
        
        cursor = connection.cursor()
        
        # Insert complaint into database
        insert_query = """
            INSERT INTO Complaints 
            (sr_no, inwardNo, name, mobile, address, reason, date, district, deptSent, priority, userName, officerName, fromDept, toDept)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """
        
        cursor.execute(insert_query, (
            sr_no, inwardNo, name, mobile, address, reason, date, district, deptSent, priority, userName, officerName, fromDept, toDept
        ))
        connection.commit()
        complaint_id = cursor.lastrowid
        
        # Trigger Officer Notification (Popup)
        # We need to find the officer's ID based on userName or officerName
        try:
            # Find officer ID logic (similar to generate_reminders)
            cursor.execute("SELECT Sr_No FROM RegistrationInfo WHERE user_name = %s", (userName,))
            officer_res = cursor.fetchone()
            if not officer_res:
                cursor.execute("SELECT Sr_No FROM RegistrationInfo WHERE Name_of_Registerer = %s", (officerName,))
                officer_res = cursor.fetchone()
            
            if officer_res:
                officer_id = officer_res[0]
                create_officer_notification(
                    officer_id=officer_id,
                    complaint_id=complaint_id,
                    title="New Complaint Assigned",
                    message=f"Complaint #{complaint_id} from {name} has been assigned to you. Priority: {priority}"
                )
        except Exception as notif_err:
            print(f"Notification Error: {notif_err}")

        # Generate Reminders
        try:
            generate_reminders_for_complaint(complaint_id)
        except Exception as reminder_err:
            print(f"Reminder generation error: {reminder_err}")
        
        return jsonify({
            'success': True,
            'message': 'तक्रार यशस्वीरित्या नोंदवली गेली!',
            'complaint_id': complaint_id
        }), 201
        
    except Error as e:
        print(f"Database error: {e}")
        return jsonify({'success': False, 'message': f'डेटाबेस त्रुटी: {str(e)}'}), 500
    finally:
        if cursor:
            cursor.close()
        if connection and connection.is_connected():
            connection.close()

# Get Complaints API Endpoint
@app.route('/api/get-complaints', methods=['GET'])
def get_complaints():
    connection = None
    cursor = None
    try:
        # Get mobile number from query parameter
        mobile = request.args.get('mobile', '').strip()
        
        if not mobile:
            return jsonify({'success': False, 'message': 'मोबाईल क्रमांक आवश्यक आहे'}), 400
        
        connection = get_db_connection()
        if not connection:
            return jsonify({'success': False, 'message': 'डेटाबेस जोडण्यात त्रुटी'}), 500
        
        cursor = connection.cursor(dictionary=True)
        
        # Get all complaints for this mobile number
        select_query = """
            SELECT complaint_id, inwardNo, name, mobile, reason, date, district, priority, deptSent, submittedAt, userName, fromDept, toDept
            FROM Complaints
            WHERE mobile = %s
            ORDER BY submittedAt DESC
        """
        
        cursor.execute(select_query, (mobile,))
        complaints = cursor.fetchall()
        
        # Format datetime for display
        formatted_complaints = []
        for complaint in complaints:
            complaint['submittedAt'] = complaint['submittedAt'].strftime('%d-%m-%Y %H:%M:%S') if complaint['submittedAt'] else ''
            formatted_complaints.append(complaint)
        
        return jsonify({
            'success': True,
            'complaints': formatted_complaints,
            'count': len(formatted_complaints)
        }), 200
        
    except Error as e:
        print(f"Database error: {e}")
        return jsonify({'success': False, 'message': f'डेटाबेस त्रुटी: {str(e)}'}), 500
    finally:
        if cursor:
            cursor.close()
        if connection and connection.is_connected():
            connection.close()

# Update Complaint Status API Endpoint
@app.route('/api/update-complaint-status/<int:complaint_id>', methods=['PUT'])
def update_complaint_status(complaint_id):
    """Update complaint status (Pending/Solved)"""
    connection = None
    cursor = None
    try:
        data = request.get_json()
        status = data.get('status', '').strip()
        
        # Validate status
        if status not in ['Pending', 'Solved']:
            return jsonify({'success': False, 'message': 'अमान्य स्थिती. Pending किंवा Solved असणे आवश्यक आहे'}), 400
        
        connection = get_db_connection()
        if not connection:
            return jsonify({'success': False, 'message': 'डेटाबेस जोडण्यात त्रुटी'}), 500
        
        cursor = connection.cursor()
        
        # Update complaint status
        update_query = "UPDATE Complaints SET status = %s WHERE complaint_id = %s"
        cursor.execute(update_query, (status, complaint_id))
        connection.commit()
        
        if cursor.rowcount > 0:
            # Trigger Officer Notification for Status Update (Optional: notify other officers or admins?)
            # For now, let's just log it or maybe notify the officer themselves as a confirmation?
            # Or better, notify the citizen (which is already separate).
            # Let's add an officer notification confirming it was updated.
            
            # First get the complaint details to find the officer
            cursor.execute("SELECT userName, officerName FROM Complaints WHERE complaint_id = %s", (complaint_id,))
            comp_details = cursor.fetchone()
            
            if comp_details:
                # Find officer ID
                officer_user = comp_details[0]
                officer_name = comp_details[1]
                
                cursor.execute("SELECT Sr_No FROM RegistrationInfo WHERE user_name = %s", (officer_user,))
                off_res = cursor.fetchone()
                if not off_res:
                    cursor.execute("SELECT Sr_No FROM RegistrationInfo WHERE Name_of_Registerer = %s", (officer_name,))
                    off_res = cursor.fetchone()
                
                if off_res:
                    create_officer_notification(
                        officer_id=off_res[0],
                        complaint_id=complaint_id,
                        title="Complaint Updated",
                        message=f"Complaint #{complaint_id} status updated to {status}."
                    )

            return jsonify({
                'success': True,
                'message': f'तक्रार स्थिती {status} मध्ये अपडेट केली गेली!'
            }), 200
        else:
            return jsonify({
                'success': False,
                'message': 'तक्रार सापडली नाही'
            }), 404
        
    except Error as e:
        print(f"Database error: {e}")
        return jsonify({'success': False, 'message': f'डेटाबेस त्रुटी: {str(e)}'}), 500
    finally:
        if cursor:
            cursor.close()
        if connection and connection.is_connected():
            connection.close()

# Update Complaint Details API Endpoint (Detailed Update Form)
@app.route('/api/update-complaint-details/<int:complaint_id>', methods=['POST'])
def update_complaint_details(complaint_id):
    """Update complaint with detailed information (inward no, acceptance method, date)"""
    connection = None
    cursor = None
    try:
        data = request.get_json()
        inward_no = data.get('inward_no', '').strip()
        acceptance_method = data.get('acceptance_method', '').strip()
        update_date = data.get('update_date', '').strip()
        status = data.get('status', 'Updated').strip()

        # Validate required fields
        if not inward_no:
            return jsonify({'success': False, 'message': 'आवक क्रमांक आवश्यक आहे'}), 400
        if not acceptance_method:
            return jsonify({'success': False, 'message': 'स्वीकार पद्धत आवश्यक आहे'}), 400
        if not update_date:
            return jsonify({'success': False, 'message': 'अपडेट तारीख आवश्यक आहे'}), 400

        # Validate acceptance method
        valid_methods = ['email', 'eoffice', 'hardcopy']
        if acceptance_method not in valid_methods:
            return jsonify({'success': False, 'message': 'अमान्य स्वीकार पद्धत'}), 400

        connection = get_db_connection()
        if not connection:
            return jsonify({'success': False, 'message': 'डेटाबेस जोडण्यात त्रुटी'}), 500

        cursor = connection.cursor()

        # First check if complaint exists
        cursor.execute("SELECT complaint_id FROM Complaints WHERE complaint_id = %s", (complaint_id,))
        if not cursor.fetchone():
            return jsonify({'success': False, 'message': f'तक्रार ID {complaint_id} सापडली नाही'}), 404

        # Update complaint with detailed information
        update_query = """
            UPDATE Complaints
            SET inwardNo = %s, status = %s, acceptance_method = %s, update_date = %s, updated_at = NOW()
            WHERE complaint_id = %s
        """
        cursor.execute(update_query, (inward_no, status, acceptance_method, update_date, complaint_id))
        connection.commit()

        if cursor.rowcount > 0:
            # Create officer notification for the detailed update
            cursor.execute("SELECT userName, officerName FROM Complaints WHERE complaint_id = %s", (complaint_id,))
            comp_details = cursor.fetchone()

            if comp_details:
                officer_user = comp_details[0]
                officer_name = comp_details[1]

                cursor.execute("SELECT Sr_No FROM RegistrationInfo WHERE user_name = %s", (officer_user,))
                off_res = cursor.fetchone()
                if not off_res:
                    cursor.execute("SELECT Sr_No FROM RegistrationInfo WHERE Name_of_Registerer = %s", (officer_name,))
                    off_res = cursor.fetchone()

                if off_res:
                    acceptance_text = {
                        'email': 'ईमेल',
                        'eoffice': 'ई-ऑफिस',
                        'hardcopy': 'हार्ड कॉपी'
                    }.get(acceptance_method, acceptance_method)

                    create_officer_notification(
                        officer_id=off_res[0],
                        complaint_id=complaint_id,
                        title="तक्रार अपडेट केली",
                        message=f"तक्रार #{complaint_id} अपडेट केली: आवक क्र. {inward_no}, स्वीकार: {acceptance_text}, तारीख: {update_date}"
                    )

            return jsonify({
                'success': True,
                'message': f'तक्रार #{complaint_id} यशस्वीरित्या अपडेट केली! आवक क्रमांक: {inward_no}'
            }), 200
        else:
            return jsonify({
                'success': False,
                'message': 'तक्रार सापडली नाही'
            }), 404

    except Error as e:
        print(f"Database error: {e}")
        return jsonify({'success': False, 'message': f'डेटाबेस त्रुटी: {str(e)}'}), 500
    finally:
        if cursor:
            cursor.close()
        if connection and connection.is_connected():
            connection.close()

# Delete Complaint API Endpoint
@app.route('/api/delete-complaint/<int:complaint_id>', methods=['DELETE'])
def delete_complaint(complaint_id):
    connection = None
    cursor = None
    try:
        connection = get_db_connection()
        if not connection:
            return jsonify({'success': False, 'message': 'डेटाबेस जोडण्यात त्रुटी'}), 500
        
        cursor = connection.cursor()
        
        # Delete complaint from database
        delete_query = "DELETE FROM Complaints WHERE complaint_id = %s"
        cursor.execute(delete_query, (complaint_id,))
        connection.commit()
        
        if cursor.rowcount > 0:
            # Trigger Officer Notification for Status Update
            try:
                # First get the complaint details to find the officer
                cursor.execute("SELECT userName, officerName FROM Complaints WHERE complaint_id = %s", (complaint_id,))
                comp_details = cursor.fetchone()
                
                if comp_details:
                    # Find officer ID
                    officer_user = comp_details[0]
                    officer_name = comp_details[1]
                    
                    cursor.execute("SELECT Sr_No FROM RegistrationInfo WHERE user_name = %s", (officer_user,))
                    off_res = cursor.fetchone()
                    if not off_res:
                        cursor.execute("SELECT Sr_No FROM RegistrationInfo WHERE Name_of_Registerer = %s", (officer_name,))
                        off_res = cursor.fetchone()
                    
                    if off_res:
                        create_officer_notification(
                            officer_id=off_res[0],
                            complaint_id=complaint_id,
                            title="Complaint Deleted",
                            message=f"Complaint #{complaint_id} has been deleted."
                        )
            except Exception as e:
                print(f"Notification error: {e}")

            return jsonify({
                'success': True,
                'message': 'तक्रार यशस्वीरित्या हटवली गेली!'
            }), 200
        else:
            return jsonify({
                'success': False,
                'message': 'तक्रार सापडली नाही'
            }), 404
        
    except Error as e:
        print(f"Database error: {e}")
        return jsonify({'success': False, 'message': f'डेटाबेस त्रुटी: {str(e)}'}), 500
    finally:
        if cursor:
            cursor.close()
        if connection and connection.is_connected():
            connection.close()


# ============================================================================
# CITIZEN NOTIFICATIONS API
# ============================================================================

@app.route('/api/citizen-notifications/<mobile_number>', methods=['GET'])
def get_citizen_notifications_api(mobile_number):
    """Get all notifications for a citizen by mobile number"""
    try:
        notifications = get_citizen_notifications(mobile_number)
        return jsonify({
            'success': True,
            'count': len(notifications),
            'notifications': notifications
        }), 200
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/api/mark-notification-read/<int:notification_id>', methods=['POST'])
def mark_notification_read_api(notification_id):
    """Mark a notification as read"""
    try:
        result = mark_notification_as_read(notification_id)
        return jsonify({
            'success': result,
            'message': 'Notification marked as read' if result else 'Failed to mark notification'
        }), 200
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500


# ============================================================================
# OFFICER NOTIFICATIONS API (Popups)
# ============================================================================

@app.route('/api/officer-notifications/<int:officer_id>', methods=['GET'])
def get_officer_notifications_api(officer_id):
    """Get unread notifications for officer"""
    try:
        notifications = get_officer_notifications(officer_id, unread_only=True)
        return jsonify({
            'success': True,
            'notifications': notifications,
            'count': len(notifications)
        }), 200
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/api/acknowledge-notification/<int:notification_id>', methods=['POST'])
def acknowledge_notification_api(notification_id):
    """Mark notification as read"""
    try:
        result = mark_officer_notification_read(notification_id)
        return jsonify({
            'success': result
        }), 200
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500


# ============================================================================
# OFFICER REMINDERS API
# ============================================================================

@app.route('/api/officer-reminders/<int:officer_id>', methods=['GET'])
def get_officer_reminders_api(officer_id):
    """Get all active reminders for an officer"""
    try:
        reminders = get_officer_reminders(officer_id)
        overdue = get_overdue_reminders(officer_id)
        stats = get_reminder_statistics(officer_id)
        
        return jsonify({
            'success': True,
            'total_reminders': len(reminders),
            'overdue_count': len(overdue),
            'reminders': reminders,
            'statistics': stats
        }), 200
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/api/acknowledge-reminder/<int:reminder_id>', methods=['POST'])
def acknowledge_reminder_api(reminder_id):
    """Acknowledge a reminder"""
    try:
        result = acknowledge_reminder(reminder_id)
        return jsonify({
            'success': result,
            'message': 'Reminder acknowledged' if result else 'Failed to acknowledge reminder'
        }), 200
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/api/resolve-reminder/<int:reminder_id>', methods=['POST'])
def resolve_reminder_api(reminder_id):
    """Resolve a reminder"""
    try:
        result = resolve_reminder(reminder_id)
        return jsonify({
            'success': result,
            'message': 'Reminder resolved' if result else 'Failed to resolve reminder'
        }), 200
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500


# ============================================================================
# CITIZEN STATUS CHECK PAGE API
# ============================================================================

@app.route('/api/check-complaint-status/<mobile_number>', methods=['GET'])
def check_complaint_status(mobile_number):
    """Check complaint status for a citizen using mobile number"""
    connection = None
    cursor = None
    try:
        connection = get_db_connection()
        if not connection:
            return jsonify({'success': False, 'message': 'Database connection failed'}), 500
        
        cursor = connection.cursor(dictionary=True)
        
        # Get all complaints for the mobile number
        cursor.execute("""
            SELECT complaint_id, inwardNo, reason, date, priority, 
                   status, submittedAt, district, officerName
            FROM Complaints 
            WHERE mobile = %s
            ORDER BY submittedAt DESC
        """, (mobile_number,))
        
        complaints = cursor.fetchall()
        
        if not complaints:
            return jsonify({
                'success': False,
                'message': 'आपल्या मोबाईल नंबरसाठी कोणतीही तक्रार सापडली नाही'
            }), 404
        
        # Get notifications for each complaint
        cursor.execute("""
            SELECT * FROM Notifications 
            WHERE mobile_number = %s
            ORDER BY created_at DESC
        """, (mobile_number,))
        
        notifications = cursor.fetchall()
        
        return jsonify({
            'success': True,
            'mobile_number': mobile_number,
            'total_complaints': len(complaints),
            'complaints': complaints,
            'notifications': notifications
        }), 200
        
    except Error as e:
        print(f"Database error: {e}")
        return jsonify({'success': False, 'message': f'Database error: {str(e)}'}), 500
    finally:
        if cursor:
            cursor.close()
        if connection and connection.is_connected():
            connection.close()


# ============================================================================
# OFFICER-WISE COMPLAINTS API
# ============================================================================

@app.route('/api/complaints-by-officer', methods=['GET'])
def get_complaints_by_officer():
    """Get complaints grouped by officers for admin dashboard"""
    connection = None
    cursor = None
    try:
        connection = get_db_connection()
        if not connection:
            return jsonify({'success': False, 'message': 'डेटाबेस जोडण्यात त्रुटी'}), 500

        cursor = connection.cursor(dictionary=True)

        # Get all complaints with officer information
        select_query = """
            SELECT c.complaint_id, c.sr_no, c.inwardNo, c.name, c.mobile, c.reason, c.date,
                   c.district, c.priority, c.deptSent, c.submittedAt, c.userName, c.status,
                   c.officerName as officer_name
            FROM Complaints c
            ORDER BY CASE 
                WHEN c.officerName IS NULL OR c.officerName = '' THEN 0
                ELSE 1
            END DESC, c.officerName, c.submittedAt DESC
        """
        cursor.execute(select_query)
        complaints = cursor.fetchall()

        # Group complaints by officer
        officer_complaints = {}
        officer_stats = {}

        for complaint in complaints:
            officer = complaint['officer_name'] or 'असाइन नाही'

            # Format datetime
            complaint['submittedAt'] = complaint['submittedAt'].strftime('%d-%m-%Y %H:%M:%S') if complaint['submittedAt'] else ''

            if officer not in officer_complaints:
                officer_complaints[officer] = []
                officer_stats[officer] = {
                    'total': 0,
                    'resolved': 0,
                    'pending': 0,
                    'urgent': 0,
                    'normal': 0
                }

            officer_complaints[officer].append(complaint)
            officer_stats[officer]['total'] += 1

            if complaint['status'] == 'Resolved':
                officer_stats[officer]['resolved'] += 1
            else:
                officer_stats[officer]['pending'] += 1

            if complaint['priority'] and 'अतितात्काळ' in complaint['priority']:
                officer_stats[officer]['urgent'] += 1
            else:
                officer_stats[officer]['normal'] += 1

        return jsonify({
            'success': True,
            'officer_complaints': officer_complaints,
            'officer_stats': officer_stats,
            'total_officers': len(officer_complaints)
        }), 200

    except Error as e:
        print(f"Database error: {e}")
        return jsonify({'success': False, 'message': f'डेटाबेस त्रुटी: {str(e)}'}), 500
    finally:
        if cursor:
            cursor.close()
        if connection and connection.is_connected():
            connection.close()


# ============================================================================
# BACKGROUND SCHEDULER
# ============================================================================
import threading
import time


# ============================================================================
# BACKGROUND SCHEDULER (Recurring Reminders)
# ============================================================================
import threading
import time

def run_scheduler():
    """Run recurring reminder check every 60 seconds"""
    print("⏳ Background scheduler started...")
    while True:
        try:
            # Import here to avoid circular dependencies if any
            from notifications import check_and_generate_recurring_reminders
            check_and_generate_recurring_reminders()
        except Exception as e:
            print(f"Scheduler Error: {e}")
        
        time.sleep(60) # Check every minute

# Start scheduler in a separate thread
scheduler_thread = threading.Thread(target=run_scheduler, daemon=True)
scheduler_thread.start()

if __name__ == '__main__':
    # Ensure tables exist
    migrate_db()
    
    print("Server starting on port 8000...")
    print("Registration page: http://localhost:8000/Registration.html")
    print("Login page: http://localhost:8000/Login.html")
    print("View Registrations: http://localhost:8000/view_registrations.html")
    app.run(debug=False, host='0.0.0.0', port=8000)