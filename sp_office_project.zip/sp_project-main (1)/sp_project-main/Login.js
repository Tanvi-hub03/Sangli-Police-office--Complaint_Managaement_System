// Toggle password visibility
function togglePasswordVisibility() {
    const passwordInput = document.getElementById('password');
    const toggleBtn = document.getElementById('togglePassword');

    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        toggleBtn.innerHTML = '<span class="eye-icon"></span>';
        toggleBtn.setAttribute('aria-label', 'Hide password');
    } else {
        passwordInput.type = 'password';
        toggleBtn.innerHTML = '<span class="eye-icon"></span>';
        toggleBtn.setAttribute('aria-label', 'Show password');
    }
}

// Validation functions
function validateUsername(username) {
    return username.trim().length >= 3;
}

function validatePassword(password) {
    return password.length >= 1; // At least 1 character (basic validation)
}

// Display error message
function showError(fieldId, errorId, message) {
    const field = document.getElementById(fieldId);
    const errorElement = document.getElementById(errorId);

    if (field) {
        field.classList.add('error');
    }
    if (errorElement) {
        errorElement.textContent = message;
    }
}

// Clear error message
function clearError(fieldId, errorId) {
    const field = document.getElementById(fieldId);
    const errorElement = document.getElementById(errorId);

    if (field) {
        field.classList.remove('error');
    }
    if (errorElement) {
        errorElement.textContent = '';
    }
}

// Show message (success or error)
function showMessage(message, type = 'success') {
    console.log(`Showing message: ${message} (${type})`);

    // Remove existing message elements
    const existingMessage = document.querySelector('.message');
    if (existingMessage) {
        existingMessage.remove();
    }

    // Create new message element
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${type} show`;
    messageDiv.textContent = message;
    messageDiv.style.display = 'block';

    // Insert at the beginning of the form
    const form = document.getElementById('loginForm');
    if (form) {
        form.insertBefore(messageDiv, form.firstChild);
        console.log('Message inserted into form');
    } else {
        // If form not found, show in body
        document.body.insertBefore(messageDiv, document.body.firstChild);
        console.log('Message inserted into body');
    }

    // Auto-hide after 5 seconds
    setTimeout(() => {
        messageDiv.style.display = 'none';
        setTimeout(() => messageDiv.remove(), 300);
    }, 5000);
}

// Handle Login Form Submission
function handleLogin(event) {
    event.preventDefault();

    // Get form values
    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value;

    // Reset all errors
    clearError('username', 'usernameError');
    clearError('password', 'passwordError');

    let isValid = true;

    // Validate Username
    if (!username || !validateUsername(username)) {
        showError('username', 'usernameError', 'कृपया वैध वापरकर्तानाव प्रविष्ट करा (किमान 3 वर्ण)');
        isValid = false;
    }

    // Validate Password
    if (!password || !validatePassword(password)) {
        showError('password', 'passwordError', 'कृपया पासवर्ड प्रविष्ट करा');
        isValid = false;
    }

    // If form is valid, process login
    if (isValid) {
        const loginBtn = document.getElementById('loginBtn');
        // Disable button and show loading state
        loginBtn.disabled = true;
        loginBtn.textContent = 'लॉगिन करत आहे...';

        const loginData = { username, password };
        console.log('Sending login data:', loginData);  // Debug log

        // Call backend API
        fetch('http://127.0.0.1:8000/api/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password })
        })
            .then(res => res.json())
            .then(data => {
                if (data.success === true) {
                    // Store full user object for Officer Dashboard
                    localStorage.setItem('user', JSON.stringify(data.user));

                    // Keep legacy keys for backward compatibility if needed
                    localStorage.setItem('officerId', data.user.sr_no);
                    localStorage.setItem('officerName', data.user.name);

                    showMessage('यशस्वीरित्या लॉगिन झाले!', 'success');
                    setTimeout(() => {
                        window.location.href = data.redirect || 'OfficerDashboard.html';
                    }, 1000);
                } else {
                    showMessage(data.message || 'वापरकर्तानाव किंवा पासवर्ड चुकीचा आहे!', 'error');
                }
            })
            .catch(err => {
                console.error(err);
                showMessage('सर्व्हरशी संपर्क होऊ शकला नाही (Failed to fetch)', 'error');
            });

        // Re-enable button after a delay
        setTimeout(() => {
            loginBtn.disabled = false;
            loginBtn.textContent = 'लॉगिन';
        }, 2000);
        // Real-time validation on input blur
        const usernameInput = document.getElementById('username');
        const passwordInput = document.getElementById('password');

        if (usernameInput) {
            usernameInput.addEventListener('blur', function () {
                const username = this.value;
                if (username && !validateUsername(username)) {
                    showError('username', 'usernameError', 'Username must be at least 3 characters');
                } else {
                    clearError('username', 'usernameError');
                }
            });
        }

        if (passwordInput) {
            passwordInput.addEventListener('blur', function () {
                const password = this.value;
                if (password && !validatePassword(password)) {
                    showError('password', 'passwordError', 'Please enter your password');
                } else {
                    clearError('password', 'passwordError');
                }
            });

            // Clear error on input
            passwordInput.addEventListener('input', function () {
                if (this.value.length > 0) {
                    clearError('password', 'passwordError');
                }
            });
        }

        // Allow form submission with Enter key
        usernameInput?.addEventListener('keypress', function (e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                passwordInput?.focus();
            }
        });

        passwordInput?.addEventListener('keypress', function (e) {
            if (e.key === 'Enter') {
                form.dispatchEvent(new Event('submit'));
            }
        });
    });

    // Forgot Password Functions
    // Open forgot password popup
    function openForgotPasswordPopup() {
        const popup = document.getElementById('forgotPasswordPopup');
        if (popup) {
            popup.classList.add('active');
            document.body.style.overflow = 'hidden'; // Prevent background scrolling
        }
    }

    // Close forgot password popup
    function closeForgotPasswordPopup() {
        const popup = document.getElementById('forgotPasswordPopup');
        if (popup) {
            popup.classList.remove('active');
            document.body.style.overflow = 'auto'; // Restore scrolling
            resetForgotPasswordForm();
        }
    }

    // Validation functions for forgot password
    function validateMobile(mobile) {
        const mobileRegex = /^[0-9]{10}$/;
        return mobileRegex.test(mobile.trim());
    }
    function validateDateOfBirth(dob) {
        if (!dob) return false;
        const birthDate = new Date(dob);
        const today = new Date();
        // Check if date is valid and not in the future
        if (birthDate > today) return false;
        return true;
    }

    // Reset forgot password form
    function resetForgotPasswordForm() {
        const form = document.getElementById('forgotPasswordForm');
        if (form) {
            form.reset();

            // Clear all error messages
            clearError('forgotMobileNumber', 'forgotMobileError');
            clearError('forgotDateOfBirth', 'forgotDobError');
        }
    }

    // Forgot password form submission
    document.addEventListener('DOMContentLoaded', function () {
        const forgotPasswordPopup = document.getElementById('forgotPasswordPopup');
        const forgotPasswordForm = document.getElementById('forgotPasswordForm');

        // Close popup when clicking outside
        if (forgotPasswordPopup) {
            forgotPasswordPopup.addEventListener('click', function (e) {
                if (e.target === forgotPasswordPopup) {
                    closeForgotPasswordPopup();
                }
            });

            // Close popup on Escape key
            document.addEventListener('keydown', function (e) {
                if (e.key === 'Escape' && forgotPasswordPopup.classList.contains('active')) {
                    closeForgotPasswordPopup();
                }
            });
        }

        // Handle forgot password form submission
        if (forgotPasswordForm) {
            forgotPasswordForm.addEventListener('submit', function (e) {
                e.preventDefault();

                // Get form values
                const mobileNumber = document.getElementById('forgotMobileNumber').value;
                const dateOfBirth = document.getElementById('forgotDateOfBirth').value;

                // Reset all errors
                clearError('forgotMobileNumber', 'forgotMobileError');
                clearError('forgotDateOfBirth', 'forgotDobError');

                let isValid = true;

                // Validate Mobile Number
                if (!mobileNumber || !validateMobile(mobileNumber)) {
                    showError('forgotMobileNumber', 'forgotMobileError', 'Please enter a valid 10-digit mobile number');
                    isValid = false;
                }

                // Validate Date of Birth
                if (!dateOfBirth || !validateDateOfBirth(dateOfBirth)) {
                    showError('forgotDateOfBirth', 'forgotDobError', 'Please enter a valid date of birth');
                    isValid = false;
                }

                // If form is valid, process password reset
                if (isValid) {
                    const submitBtn = forgotPasswordForm.querySelector('.submit-btn');
                    if (submitBtn) {
                        submitBtn.disabled = true;
                        submitBtn.textContent = 'Processing...';
                    }

                    // Here you would typically make an AJAX call to your backend
                    console.log('Forgot Password Data:', {
                        mobileNumber: mobileNumber,
                        dateOfBirth: dateOfBirth
                    });

                    // Example API call (uncomment and modify as needed):
                    // fetch('/api/forgot-password', {
                    //     method: 'POST',
                    //     headers: { 'Content-Type': 'application/json' },
                    //     body: JSON.stringify({ mobileNumber, dateOfBirth })
                    // })
                    // .then(response => response.json())
                    // .then(data => {
                    //     if (data.success) {
                    //         alert('Password reset link has been sent to your mobile number!');
                    //         closeForgotPasswordPopup();
                    //     } else {
                    //         showError('forgotMobileNumber', 'forgotMobileError', data.message || 'Invalid credentials. Please check your mobile number and date of birth.');
                    //         submitBtn.disabled = false;
                    //         submitBtn.textContent = 'Reset Password';
                    //     }
                    // })
                    // .catch(error => {
                    //     console.error('Forgot password error:', error);
                    //     showError('forgotMobileNumber', 'forgotMobileError', 'An error occurred. Please try again.');
                    //     submitBtn.disabled = false;
                    //     submitBtn.textContent = 'Reset Password';
                    // });

                    // For demonstration purposes, simulate successful submission
                    setTimeout(() => {
                        alert('Password reset link has been sent to your mobile number!\n\nMobile: ' + mobileNumber + '\nDate of Birth: ' + dateOfBirth);
                        closeForgotPasswordPopup();

                        if (submitBtn) {
                            submitBtn.disabled = false;
                            submitBtn.textContent = 'Reset Password';
                        }

                        // In production, use the API call above instead
                    }, 1000);
                }
            });

            // Real-time validation on input blur
            const mobileInput = document.getElementById('forgotMobileNumber');
            const dobInput = document.getElementById('forgotDateOfBirth');

            if (mobileInput) {
                mobileInput.addEventListener('blur', function () {
                    const mobile = this.value;
                    if (mobile && !validateMobile(mobile)) {
                        showError('forgotMobileNumber', 'forgotMobileError', 'Please enter a valid 10-digit mobile number');
                    } else {
                        clearError('forgotMobileNumber', 'forgotMobileError');
                    }
                });
            }

            if (dobInput) {
                dobInput.addEventListener('blur', function () {
                    const dob = this.value;
                    if (dob && !validateDateOfBirth(dob)) {
                        showError('forgotDateOfBirth', 'forgotDobError', 'Please enter a valid date of birth');
                    } else {
                        clearError('forgotDateOfBirth', 'forgotDobError');
                    }
                });
            }
        }
    });

