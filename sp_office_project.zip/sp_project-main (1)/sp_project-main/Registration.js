// Password visibility toggle functionality
document.addEventListener('DOMContentLoaded', function() {
    
    // Toggle password visibility for password field
    const togglePassword1 = document.getElementById('togglePassword1');
    if (togglePassword1) {
        togglePassword1.addEventListener('click', function() {
            togglePasswordVisibility('password', 'eyeIcon1');
        });
    }

    // Toggle password visibility for confirm password field
    const togglePassword2 = document.getElementById('togglePassword2');
    if (togglePassword2) {
        togglePassword2.addEventListener('click', function() {
            togglePasswordVisibility('confirmPassword', 'eyeIcon2');
        });
    }

    // Cancel button functionality
    const cancelBtn = document.getElementById('cancelBtn');
    if (cancelBtn) {
        cancelBtn.addEventListener('click', function() {
            window.location.href = 'Login.html';
        });
    }

    // Handle registration form submission
    const registrationForm = document.getElementById('registrationForm');
    if (registrationForm) {
        registrationForm.addEventListener('submit', handleRegistration);
    }
});

// Toggle password visibility function
function togglePasswordVisibility(inputId, iconId) {
    const passwordInput = document.getElementById(inputId);
    const eyeIcon = document.getElementById(iconId);
    
    if (passwordInput && eyeIcon) {
        if (passwordInput.type === 'password') {
            passwordInput.type = 'text';
            eyeIcon.textContent = '🙈';
        } else {
            passwordInput.type = 'password';
            eyeIcon.textContent = '👁️';
        }
    }
}

// Handle registration form submission
function handleRegistration(event) {
    event.preventDefault();
    
    // Get form values
    const fullName = document.getElementById('fullName').value.trim();
    const address = document.getElementById('address').value.trim();
    const dateOfBirth = document.getElementById('dateOfBirth').value;
    const mobileNumber = document.getElementById('mobileNumber').value.trim();
    const email = document.getElementById('email').value.trim();
    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
    const district = document.getElementById('district').value.trim();
    const registerBtn = document.getElementById('registerBtn');
    
    // Clear previous errors
    document.querySelectorAll('.error-message').forEach(el => el.style.display = 'none');
    
    let isValid = true;
    
    // Validation
    if (!fullName) {
        showError('nameError', 'कृपया संपूर्ण नाव प्रविष्ट करा');
        isValid = false;
    }
    
    if (!address) {
        showError('addressError', 'कृपया पत्ता प्रविष्ट करा');
        isValid = false;
    }
    
    if (!dateOfBirth) {
        showError('dobError', 'कृपया जन्मतारीख निवडा');
        isValid = false;
    } else {
        // Check if date is not in the future
        const birthDate = new Date(dateOfBirth);
        const today = new Date();
        if (birthDate > today) {
            showError('dobError', 'जन्मतारीख भविष्यात असू शकत नाही');
            isValid = false;
        }
    }
    
    // Mobile number validation (Indian mobile number format)
    const mobileRegex = /^[6-9]\d{9}$/;
    if (!mobileNumber || !mobileRegex.test(mobileNumber)) {
        showError('mobileError', 'कृपया वैध १० अंकी मोबाइल नंबर प्रविष्ट करा');
        isValid = false;
    }
    
    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!email || !emailRegex.test(email)) {
        showError('emailError', 'कृपया वैध ई-मेल पत्ता प्रविष्ट करा');
        isValid = false;
    }

    // District validation
    if (!district) {
        showError('districtError', 'कृपया जिल्हा निवडा');
        isValid = false;
    }
    
    // Username validation
    if (!username || username.length < 3) {
        showError('usernameError', 'वापरकर्तानाव किमान ३ वर्णांचे असणे आवश्यक आहे');
        isValid = false;
    }
    
    // Password validation
    if (!password || password.length < 6) {
        showError('passwordError', 'पासवर्ड किमान ६ वर्णांचा असणे आवश्यक आहे');
        isValid = false;
    }
    
    // Confirm password validation
    if (password !== confirmPassword) {
        showError('confirmPasswordError', 'पासवर्ड जुळत नाही');
        isValid = false;
    }
    
    if (!isValid) {
        return;
    }
    
    // Disable button and show loading
    registerBtn.disabled = true;
    registerBtn.textContent = 'नोंदणी करत आहे...';
    
    // Prepare registration data
    const registrationData = {
        fullName: fullName,
        address: address,
        dateOfBirth: dateOfBirth,
        mobileNumber: mobileNumber,
        email: email,
        username: username,
        password: password,
        district: district
    };
    
    // Send to backend API (MySQL Database)
    try {
        fetch('http://localhost:5000/api/register', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(registrationData)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('नोंदणी यशस्वी झाली! कृपया लॉगिन करा. आपला क्रमांक: ' + data.sr_no);
                // Redirect to login page
                window.location.href = 'Login.html';
            } else {
                alert(data.message || 'नोंदणी अयशस्वी झाली. कृपया पुन्हा प्रयत्न करा.');
                registerBtn.disabled = false;
                registerBtn.textContent = 'नोंदणी करा';
            }
        })
        .catch(error => {
            console.error('Registration error:', error);
            alert('त्रुटी आली. कृपया पुन्हा प्रयत्न करा. सर्व तपशील तपासा आणि पुन्हा प्रयत्न करा.');
            registerBtn.disabled = false;
            registerBtn.textContent = 'नोंदणी करा';
        });
    } catch (error) {
        console.error('Error:', error);
        alert('त्रुटी आली. कृपया पुन्हा प्रयत्न करा.');
        registerBtn.disabled = false;
        registerBtn.textContent = 'नोंदणी करा';
    }
}

// Helper function to show error messages
function showError(elementId, message) {
    const errorElement = document.getElementById(elementId);
    if (errorElement) {
        errorElement.textContent = message;
        errorElement.style.display = 'block';
    }
}

// Real-time validation on blur
document.addEventListener('DOMContentLoaded', function() {
    
    // Full Name validation on blur
    const fullNameInput = document.getElementById('fullName');
    if (fullNameInput) {
        fullNameInput.addEventListener('blur', function() {
            const fullName = this.value.trim();
            if (fullName && fullName.length < 3) {
                showError('nameError', 'नाव किमान ३ वर्णांचे असणे आवश्यक आहे');
            } else if (fullName) {
                document.getElementById('nameError').style.display = 'none';
            }
        });
    }
    
    // Mobile number validation on blur
    const mobileInput = document.getElementById('mobileNumber');
    if (mobileInput) {
        mobileInput.addEventListener('blur', function() {
            const mobile = this.value.trim();
            const mobileRegex = /^[6-9]\d{9}$/;
            if (mobile && !mobileRegex.test(mobile)) {
                showError('mobileError', 'कृपया वैध १० अंकी मोबाइल नंबर प्रविष्ट करा');
            } else if (mobile) {
                document.getElementById('mobileError').style.display = 'none';
            }
        });
        
        // Only allow numbers
        mobileInput.addEventListener('input', function() {
            this.value = this.value.replace(/[^0-9]/g, '');
        });
    }
    
    // Email validation on blur
    const emailInput = document.getElementById('email');
    if (emailInput) {
        emailInput.addEventListener('blur', function() {
            const email = this.value.trim();
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (email && !emailRegex.test(email)) {
                showError('emailError', 'कृपया वैध ई-मेल पत्ता प्रविष्ट करा');
            } else if (email) {
                document.getElementById('emailError').style.display = 'none';
            }
        });
    }
    
    // Username validation on blur
    const usernameInput = document.getElementById('username');
    if (usernameInput) {
        usernameInput.addEventListener('blur', function() {
            const username = this.value.trim();
            if (username && username.length < 3) {
                showError('usernameError', 'वापरकर्तानाव किमान ३ वर्णांचे असणे आवश्यक आहे');
            } else if (username) {
                document.getElementById('usernameError').style.display = 'none';
            }
        });
    }
    
    // Password validation on blur
    const passwordInput = document.getElementById('password');
    if (passwordInput) {
        passwordInput.addEventListener('blur', function() {
            const password = this.value;
            if (password && password.length < 6) {
                showError('passwordError', 'पासवर्ड किमान ६ वर्णांचा असणे आवश्यक आहे');
            } else if (password) {
                document.getElementById('passwordError').style.display = 'none';
            }
        });
    }
    
    // Confirm password validation on blur
    const confirmPasswordInput = document.getElementById('confirmPassword');
    if (confirmPasswordInput) {
        confirmPasswordInput.addEventListener('blur', function() {
            const password = document.getElementById('password').value;
            const confirmPassword = this.value;
            if (confirmPassword && password !== confirmPassword) {
                showError('confirmPasswordError', 'पासवर्ड जुळत नाही');
            } else if (confirmPassword) {
                document.getElementById('confirmPasswordError').style.display = 'none';
            }
        });
    }
});